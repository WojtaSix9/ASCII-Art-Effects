// Test scen: ksztalt klatki, determinizm, dostep losowy, pętla, wydajnosc.
// Uruchomienie: node scripts/check.ts [id-sceny ...]
import { createHash } from "node:crypto";
import { writeFileSync } from "node:fs";
import { pieces } from "../src/registry.ts";

const MAX_SECONDS = 60;          // jak daleko szukamy pętli
const hash = (s: string) => createHash("sha1").update(s).digest("hex").slice(0, 12);

const only = process.argv.slice(2);
const ids = Object.keys(pieces).filter((id) => !only.length || only.includes(id));
const out: any[] = [];

for (const id of ids) {
  const p = pieces[id];
  const { cols, rows, fps } = p.meta;
  const r: any = { id, cols, rows, fps };
  const dt = 1 / fps;

  // A. ksztalt
  const f0 = p.default()(0);
  const lines = f0.split("\n");
  r.shapeOk = lines.length === rows && lines.every((l) => l.length === cols);

  // B. jedna instancja, przebieg sekwencyjny do MAX_SECONDS
  const N = Math.round(MAX_SECONDS * fps);
  const A = p.default();
  const H: string[] = [];
  const t0 = performance.now();
  for (let k = 0; k <= N + 1; k++) H.push(hash(A(k * dt)));
  r.msPerFrame = +((performance.now() - t0) / (N + 2)).toFixed(2);

  // C. determinizm: druga, swieza instancja, ten sam przebieg (pierwsze 6 s)
  const B = p.default();
  const M = Math.round(6 * fps);
  r.deterministic = true;
  for (let k = 0; k <= M; k++) if (hash(B(k * dt)) !== H[k]) { r.deterministic = false; r.firstMismatch = k; break; }

  // D. idempotencja: to samo t dwa razy z rzedu
  const C = p.default();
  C(3);
  r.idempotent = hash(C(3)) === hash(C(3));

  // E. dostep losowy: swieza instancja, skok od razu do klatki K
  r.randomAccess = {};
  for (const sec of [0.5, 2.5, 10, 30]) {
    const K = Math.round(sec * fps);
    const fresh = p.default();
    r.randomAccess[sec] = hash(fresh(K * dt)) === H[K];
  }
  // F. powrot wstecz po przebiegu: A(0) po 60 s
  r.backToZero = hash(A(0)) === H[0];

  // G. pętla: najmniejsze k>0, dla ktorego klatki k i k+1 rowna sie klatkom 0 i 1
  let loop: number | null = null;
  for (let k = 1; k <= N; k++) if (H[k] === H[0] && H[k + 1] === H[1]) { loop = k; break; }
  r.loopSeconds = loop === null ? null : +(loop * dt).toFixed(3);

  out.push(r);
  console.log(
    id.padEnd(20),
    `${cols}x${rows}@${fps}`.padEnd(10),
    `shape:${r.shapeOk ? "ok" : "BLAD"}`.padEnd(10),
    `det:${r.deterministic ? "ok" : "BLAD"}`.padEnd(8),
    `idem:${r.idempotent ? "ok" : "BLAD"}`.padEnd(9),
    `rand:${Object.values(r.randomAccess).every(Boolean) ? "ok" : "BLAD"}`.padEnd(10),
    `back0:${r.backToZero ? "ok" : "BLAD"}`.padEnd(10),
    `loop:${r.loopSeconds ?? "-"}`.padEnd(11),
    `${r.msPerFrame}ms`,
  );
}
writeFileSync(new URL("../reports/check.json", import.meta.url), JSON.stringify(out, null, 1));
