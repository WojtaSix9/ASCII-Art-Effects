#!/bin/sh
# Kazda scena w osobnym procesie, kolejno (1 rdzen). Wynik: reports/loops-tol.d/*.json
node -e 'import("./src/registry.ts").then(m=>console.log(Object.keys(m.pieces).join("\n")))' | while read id; do
  node --max-old-space-size=1500 scripts/find-loops-tol.ts "$id" 180 2>&1 | grep -E "^(A\?|[ABC]) "
done
