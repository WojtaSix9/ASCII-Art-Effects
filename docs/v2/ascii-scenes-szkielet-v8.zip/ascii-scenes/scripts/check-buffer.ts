// Zgodnosc sciezki buforowej (bez kanwy) ze sciezka kanwowa. node --expose-gc scripts/check-buffer.ts
import { createCanvas } from '@napi-rs/canvas';
import { writeFileSync } from 'node:fs';
import { getScene, sceneIds, rasterizer, ensureFont, renderOptions } from '../src/export-node.ts';
import { ScenePlayer } from '../src/player.ts';
ensureFont();
const rows: string[] = []; let worst = 0, worstId = '', anyBig = 0;
for (const id of sceneIds()) {
  const { piece, meta } = getScene(id); const o = renderOptions(meta, {}); const pl = new ScenePlayer(piece, id);
  const c = createCanvas(o.width, o.height); rasterizer.renderFrameInto(c, pl, meta, 20, o);
  const ref = c.getContext('2d').getImageData(0, 0, o.width, o.height).data;
  const buf = Buffer.alloc(o.width * o.height * 4); rasterizer.renderFrameToBuffer(buf, pl, meta, 20, o);
  let max = 0, n1 = 0, n2 = 0; for (let i = 0; i < buf.length; i++) { const d = Math.abs(buf[i] - ref[i]); if (d > max) max = d; if (d > 1) n2++; else if (d === 1) n1++; }
  if (max > worst) { worst = max; worstId = id; } if (max > 1) anyBig++;
  rows.push(`${max <= 1 ? 'OK  ' : 'FAIL'} ${id.padEnd(20)} max|diff|=${max}  px(diff=1)=${n1}  px(diff>1)=${n2}`);
}
// przezroczyste tlo: alfa identyczna (+-1), rgb tam gdzie alfa>=128 (+-2)
{
  const id = 'big-text'; const { piece, meta } = getScene(id); const o = renderOptions(meta, { background: null }); const pl = new ScenePlayer(piece, id);
  const c = createCanvas(o.width, o.height); rasterizer.renderFrameInto(c, pl, meta, 20, o);
  const ref = c.getContext('2d').getImageData(0, 0, o.width, o.height).data; const buf = Buffer.alloc(o.width * o.height * 4); rasterizer.renderFrameToBuffer(buf, pl, meta, 20, o);
  let ma = 0, mc = 0; for (let i = 0; i < buf.length; i += 4) { ma = Math.max(ma, Math.abs(buf[i + 3] - ref[i + 3])); if (ref[i + 3] >= 128) for (let j = 0; j < 3; j++) mc = Math.max(mc, Math.abs(buf[i + j] - ref[i + j])); }
  rows.push(`${ma <= 1 && mc <= 2 ? 'OK  ' : 'FAIL'} przezroczyste tlo big-text: max|d alfa|=${ma}, max|d rgb| (alfa>=128)=${mc}`);
}
// bufor niewlasciwego rozmiaru i kolor spoza #hex
{ const { piece, meta } = getScene('donut'); const o = renderOptions(meta, {}); const pl = new ScenePlayer(piece, 'donut');
  const thr = (f: () => unknown) => { try { f(); return false; } catch { return true; } };
  rows.push(`${thr(() => rasterizer.renderFrameToBuffer(Buffer.alloc(10), pl, meta, 0, o)) && thr(() => rasterizer.renderFrameToBuffer(Buffer.alloc(o.width * o.height * 4), pl, meta, 0, { ...o, ink: 'red' })) ? 'OK  ' : 'FAIL'} bledy: zly rozmiar bufora, kolor nie-hex`); }
const out = rows.join('\n') + `\n\nnajgorsza roznica na kanal: ${worst} (${worstId}); scen z max>1: ${anyBig}\n`;
writeFileSync('reports/buffer-check.txt', out); console.log(out);
