// Test renderera offline na 30 prawdziwych scenach (przez ScenePlayer).
// Uruchomienie: node scripts/check-render.ts [id ...]
import { createCanvas, GlobalFonts } from "@napi-rs/canvas";
import { createHash } from "node:crypto";
import { mkdirSync, writeFileSync } from "node:fs";
import { pieces } from "../src/registry.ts";
import { ScenePlayer } from "../src/player.ts";
import { createRasterizer } from "../src/render.ts";

GlobalFonts.registerFromPath("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", "DejaVu Sans Mono");
const mk = (w: number, h: number) => createCanvas(w, h);
const hash = (c: any) => createHash("sha1").update(Buffer.from(c.getContext("2d").getImageData(0, 0, c.width, c.height).data.buffer)).digest("hex").slice(0, 12);
const O = { width: 1280, height: 720, ink: "#7CFFB2", background: "#0a0a0a" };
const only = process.argv.slice(2);
const ids = Object.keys(pieces).filter((id) => !only.length || only.includes(id));
mkdirSync("reports/frames", { recursive: true });

const shared = createRasterizer(mk);
const rows: any[] = [];
const allChars = new Set<string>();
for (const id of ids) {
  const piece = pieces[id]; const meta = piece.meta;
  const r: any = { id, cols: meta.cols, rows: meta.rows, cell: meta.cell ?? 2, fps: meta.fps };
  const ks = [0, 7, 30, 12]; // kolejnosc zawiera skok do przodu i cofniecie
  // A: dwie swieze pary (player + rasteryzator) po tej samej sciezce k
  const run = () => { const p = new ScenePlayer(piece, id); const ra = createRasterizer(mk); return ks.map((k) => hash(ra.renderFrame(p, meta, k, O))); };
  const h1 = run(), h2 = run();
  r.repeatable = h1.every((h, i) => h === h2[i]);
  // B: ta sama klatka po skoku: k=12 przez inny rasteryzator, ale ten sam wspolny
  const pj = new ScenePlayer(piece, id);
  const seq = new ScenePlayer(piece, id);
  const hSeq: string[] = []; for (let k = 0; k <= 30; k++) hSeq.push(hash(shared.renderFrame(seq, meta, k, O)));
  r.jumpMatchesSequential = [30, 12, 7, 0, 30].every((k) => hash(shared.renderFrame(pj, meta, k, O)) === hSeq[k]);
  // C: znaki (punkty kodowe) i ksztalt wg renderera
  let shapeOk = true;
  for (const k of ks) { const t = new ScenePlayer(piece, id).at(k); for (const c of t.replace(/\n/g, "")) allChars.add(c); }
  try { shared.renderFrame(new ScenePlayer(piece, id), meta, 3, O); } catch (e: any) { shapeOk = false; r.shapeError = String(e.message); }
  r.shapeOk = shapeOk;
  // D: czas 1080p, 20 kolejnych klatek
  const pt = new ScenePlayer(piece, id); const t0 = performance.now();
  for (let k = 0; k < 20; k++) shared.renderFrame(pt, meta, k, { ...O, width: 1920, height: 1080 });
  r.msRender1080p = +((performance.now() - t0) / 20).toFixed(2);
  if (["donut", "doom-fire", "big-text", "tesseract", "tv-static", "synthwave", "falling-sand", "glitch"].includes(id)) writeFileSync(`reports/frames/${id}.png`, shared.renderFrame(new ScenePlayer(piece, id), meta, 20, O).toBuffer("image/png"));
  rows.push(r);
}
mkdirSync("reports/render-check.d", { recursive: true });
for (const r of rows) writeFileSync(`reports/render-check.d/${r.id}.json`, JSON.stringify({ ...r, chars: Array.from(allChars).sort().join("") }));
console.log(rows.map((r) => `${r.repeatable && r.jumpMatchesSequential && r.shapeOk ? "OK  " : "FAIL"} ${r.id.padEnd(20)} ${r.cols}x${r.rows} cell=${r.cell} ${r.msRender1080p}ms ${r.shapeError ?? ""}`).join("\n"));
console.log("unikalne znaki:", allChars.size);
