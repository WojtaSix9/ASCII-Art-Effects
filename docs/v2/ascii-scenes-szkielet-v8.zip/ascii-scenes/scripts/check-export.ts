// Test eksportu PNG i tekstu (krok 4.1). Uruchomienie: node --expose-gc scripts/check-export.ts
import { createCanvas, loadImage } from '@napi-rs/canvas';
import { createHash } from 'node:crypto';
import { writeFileSync, mkdirSync } from 'node:fs';
import { exportPng, exportText, getScene, sceneIds, renderOptions, rasterizer, ensureFont, resolveSize } from '../src/export-node.ts';
import { ScenePlayer } from '../src/player.ts';

ensureFont();
const res: [string, boolean, string][] = [];
const ok = (name: string, cond: boolean, d = '') => res.push([name, cond, d]);
const pix = (c: any) => c.getContext('2d').getImageData(0, 0, c.width, c.height).data as Uint8ClampedArray;
const hash = (c: any) => createHash('sha1').update(Buffer.from(pix(c).buffer)).digest('hex').slice(0, 12);
async function decode(buf: Buffer) { const im = await loadImage(buf); const c = createCanvas(im.width, im.height); c.getContext('2d').drawImage(im, 0, 0); return c; }
const mb = () => Math.round(process.memoryUsage().rss / 1048576);

// 1. PNG == renderer, piksel w piksel (nieprzezroczyste tlo)
for (const [id, k] of [['donut', 20], ['big-text', 20], ['synthwave', 20], ['doom-fire', 40]] as const) {
  const { piece, meta } = getScene(id); const o = renderOptions(meta, {});
  const direct = rasterizer.renderFrame(new ScenePlayer(piece, id), meta, k, o);
  const dec = await decode(exportPng(id, k));
  ok(`PNG == renderer piksel w piksel: ${id} k=${k}`, dec.width === o.width && dec.height === o.height && hash(dec) === hash(direct), `${dec.width}x${dec.height}`);
}
// 2. przezroczyste tlo
{
  const dec = await decode(exportPng('big-text', 20, { background: null })); const d = pix(dec);
  let a0 = 0, a255 = 0; for (let i = 3; i < d.length; i += 4) { if (d[i] === 0) a0++; else if (d[i] === 255) a255++; }
  ok('PNG przezroczysty: naroznik alfa=0, sa piksele pelne', d[3] === 0 && a0 > d.length / 8 && a255 > 0, `alfa0=${(a0 / (d.length / 4) * 100).toFixed(0)}% alfa255=${a255}`);
}
// 3. tekst == scena, ksztalt, dla wszystkich scen
{
  let bad: string[] = [];
  for (const id of sceneIds()) for (const k of [0, 7]) {
    const { piece, meta } = getScene(id); const t = exportText(id, k); const raw = new ScenePlayer(piece, id).at(k);
    const rows = t.replace(/\n$/, '').split('\n');
    if (t !== raw + '\n' || rows.length !== meta.rows || rows.some((r) => Array.from(r).length !== meta.cols)) bad.push(`${id}@${k}`);
  }
  ok('tekst == ScenePlayer.at(k)+"\\n", ksztalt rows x cols, 30 scen x k=0,7', bad.length === 0, bad.join(','));
  const tr = exportText('donut', 7, { trimEnd: true }); ok('trimEnd: brak spacji na koncach linii', tr.split('\n').every((l) => l === l.replace(/\s+$/, '')));
}
// 4. scena sekwencyjna: klatka 40 z odtwarzacza swiezego == klatka 40 po kolei
{
  const { piece } = getScene('doom-fire'); const seq = new ScenePlayer(piece, 'doom-fire'); let last = '';
  for (let k = 0; k <= 40; k++) last = seq.at(k);
  ok('doom-fire (sekwencyjna): eksport k=40 == przebieg kolejny', exportText('doom-fire', 40) === last + '\n');
}
// 5. tryby rozmiaru i bledy wejscia
{
  const { meta } = getScene('donut'); const cp = resolveSize(meta, { cellPx: 24 });
  const dec = await decode(exportPng('donut', 5, { size: { cellPx: 24 } }));
  ok('cellPx=24: rozmiar = siatka', cp.width === 40 * 24 && cp.height === 22 * 48 && dec.width === cp.width && dec.height === cp.height, `${dec.width}x${dec.height}`);
  const d2 = await decode(exportPng('donut', 5, { size: { width: 1280, height: 720 } })); ok('rozmiar staly 1280x720', d2.width === 1280 && d2.height === 720);
  const thr = (f: () => unknown) => { try { f(); return false; } catch { return true; } };
  ok('bledy: nieznana scena, k<0, k niecalkowite, zly rozmiar', thr(() => exportText('nie-ma', 0)) && thr(() => exportText('donut', -1)) && thr(() => exportText('donut', 1.5)) && thr(() => exportPng('donut', 0, { size: { width: 0, height: 10 } })));
}
// 6. jedna kanwa wielokrotnie: pamiec i zgodnosc z kanwa swieza, w jednym procesie
{
  const o = { width: 1920, height: 1080, ink: '#7CFFB2', background: '#0a0a0a' };
  const shared = createCanvas(o.width, o.height); (globalThis as any).gc?.(); const m0 = mb(); let sameAll = true, n = 0;
  for (const id of ['donut', 'big-text', 'doom-fire']) {
    const { piece, meta } = getScene(id); const pl = new ScenePlayer(piece, id);
    for (let k = 0; k < 300; k++) {
      rasterizer.renderFrameInto(shared, pl, meta, k, o); n++;
      if (k % 100 === 99) { const fresh = rasterizer.renderFrame(new ScenePlayer(piece, id), meta, k, o); sameAll = sameAll && hash(fresh) === hash(shared); }
    }
  }
  (globalThis as any).gc?.(); const m1 = mb();
  ok(`jedna kanwa: ${n} klatek 1080p w jednym procesie, zgodna ze swieza kanwa`, sameAll, `RSS ${m0} -> ${m1} MB`);
  ok('jedna kanwa: RSS nie rosnie o wiecej niz 300 MB', m1 - m0 < 300, `+${m1 - m0} MB`);
  // przezroczystosc po nieprzezroczystej na tej samej kanwie
  const { piece, meta } = getScene('big-text'); rasterizer.renderFrameInto(shared, new ScenePlayer(piece, 'big-text'), meta, 20, { ...o, background: null });
  ok('ta sama kanwa: po tle nieprzezroczystym tlo=null daje alfa=0 w naroznikach', pix(shared)[3] === 0);
}
// 7. dym: 30 scen x (PNG k=0, PNG k=12) w jednym procesie (kanwy swieze): pamiec
{
  (globalThis as any).gc?.(); const m0 = mb(); let bytes = 0;
  for (const id of sceneIds()) for (const k of [0, 12]) bytes += exportPng(id, k).length;
  (globalThis as any).gc?.(); const m1 = mb();
  ok('dym: 60 PNG 1080p (30 scen x 2) bez zabicia procesu', true, `RSS ${m0} -> ${m1} MB, razem ${(bytes / 1048576).toFixed(1)} MB PNG`);
}
mkdirSync('reports', { recursive: true });
const out = res.map(([n, c, d]) => `${c ? 'OK  ' : 'FAIL'} ${n}${d ? '  [' + d + ']' : ''}`).join('\n') + '\n';
writeFileSync('reports/export-check.txt', out); console.log(out);
console.log(`${res.filter((r) => r[1]).length}/${res.length} OK`);
