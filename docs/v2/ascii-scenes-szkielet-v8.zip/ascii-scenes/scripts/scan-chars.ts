// Zbiera wszystkie znaki uzywane przez sceny w pierwszych 60 s (bez canvasa). Wynik: reports/chars.json
import { writeFileSync } from "node:fs";
import { pieces } from "../src/registry.ts";
import { ScenePlayer } from "../src/player.ts";
const per: Record<string, string> = {}; const all = new Set<string>();
for (const id of Object.keys(pieces)) {
  const p = pieces[id]; const pl = new ScenePlayer(p, id); const s = new Set<string>();
  const N = Math.round(60 * (p.meta.fps || 1));
  for (let k = 0; k <= N; k += 1) for (const c of pl.at(k)) if (c !== "\n") { s.add(c); all.add(c); }
  per[id] = Array.from(s).sort().join("");
}
writeFileSync("reports/chars.json", JSON.stringify({ all: Array.from(all).sort().join(""), per }, null, 1));
console.log("unikalnych:", all.size);
