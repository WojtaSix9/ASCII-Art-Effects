#!/bin/bash
# Test dymny 30 scen: kazda scena w osobnym procesie. Wynik: reports/smoke.jsonl
cd "$(dirname "$0")/.."
: > reports/smoke.jsonl
for id in $(node scripts/export.ts --list); do node scripts/smoke-one.ts "$id" 2 >> reports/smoke.jsonl 2>/tmp/smoke-err-$id.txt; done
echo done > reports/smoke.done
