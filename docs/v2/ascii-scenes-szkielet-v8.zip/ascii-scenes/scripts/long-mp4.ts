// Test dlugiego klipu: czas i pamiec. node scripts/long-mp4.ts [scena] [wyjscie]   (domyslnie donut, pelna petla 1080p)
import { statSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { exportMp4 } from '../src/export-video.ts';
const id = process.argv[2] ?? 'donut'; const out = process.argv[3] ?? `/tmp/mp4check/${id}-long.mp4`;
const mb = () => Math.round(process.memoryUsage().rss / 1048576); const t0 = performance.now(); let peak = 0;
const r = await exportMp4(id, out, { onProgress: (d, t) => { peak = Math.max(peak, mb()); if (d % 500 === 0 || d === t) console.log(`${d}/${t} klatek, ${((performance.now() - t0) / 1000).toFixed(0)} s, RSS node ${mb()} MB`); } });
const s = JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-count_frames', '-select_streams', 'v:0', '-show_entries', 'stream=nb_read_frames,duration,width,height', '-of', 'json', out]).toString()).streams[0];
console.log(`KONIEC ${id}: ${r.clip.frames} klatek zapisanych, ffprobe ${s.nb_read_frames} klatek, ${Number(s.duration).toFixed(3)} s, ${s.width}x${s.height}, plik ${(statSync(out).size / 1048576).toFixed(1)} MB, ${((performance.now() - t0) / 1000).toFixed(0)} s, szczyt RSS node ${peak} MB`);
