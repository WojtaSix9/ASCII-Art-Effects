#!/bin/sh
# Kazda scena w osobnym procesie (natywne kanwy nie sa zwalniane miedzy scenami i proces wyczerpuje pamiec).
node -e 'import("./src/registry.ts").then(m=>console.log(Object.keys(m.pieces).join("\n")))' | while read id; do
  node --max-old-space-size=1024 scripts/check-render.ts "$id" 2>&1 | grep -E "^(OK|FAIL)"
done
