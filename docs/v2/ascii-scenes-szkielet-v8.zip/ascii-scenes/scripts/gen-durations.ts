// Generuje src/durations.ts z reports/loops-tol.json. Uruchomienie: node scripts/gen-durations.ts
import { readFileSync, writeFileSync } from 'node:fs';
const rows = JSON.parse(readFileSync('reports/loops-tol.json', 'utf8')) as any[];
const body = rows.map((r) => {
  const rec = r.recommended;
  return `  ${JSON.stringify(r.id)}: { fps: ${r.fps}, loopFrames: ${rec ? rec.k : 'null'}, loopSeconds: ${rec ? rec.seconds : 'null'}, exactSeconds: ${r.exactSeconds ?? 'null'}, cls: ${JSON.stringify(r.class)} },`;
}).join('\n');
writeFileSync('src/durations.ts', `// GENEROWANE przez scripts/gen-durations.ts z reports/loops-tol.json. Nie edytowac recznie.
// loopFrames/loopSeconds: rekomendowana petla (ratio <= 0.25, zob. reports/LOOPS.md), null = brak petli.
// exactSeconds: dokladna petla (test rownosci okna 2 s w 180 s), null = brak.
// cls: A = jest rekomendowana petla, A? = tylko graniczna, B = szum, C = brak petli.
export type DurationInfo = { fps: number; loopFrames: number | null; loopSeconds: number | null; exactSeconds: number | null; cls: string };
export const DURATIONS: Record<string, DurationInfo> = {
${body}
};
`);
console.log('zapisano src/durations.ts,', rows.length, 'scen');
