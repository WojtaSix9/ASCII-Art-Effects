// Test geometrycznych glifow (src/glyphs.ts): szwy, sumy cwiartek/polowek, lacznosc ramek, gestosc cieniowania.
// Uruchomienie: node scripts/check-glyphs.ts
import { createCanvas } from "@napi-rs/canvas";
import { drawGeometric } from "../src/glyphs.ts";

type Res = [string, boolean, string];
const res: Res[] = [];

function draw(rowsText: string[], cw: number, ch: number, alphaMin = 128) {
  const cols = Math.max(...rowsText.map((r) => Array.from(r).length));
  const W = cols * cw, H = rowsText.length * ch;
  const c = createCanvas(W, H); const g = c.getContext("2d");
  g.fillStyle = "#fff";
  rowsText.forEach((row, r) => Array.from(row).forEach((ch_, i) => {
    if (ch_ === " ") return;
    g.save(); g.beginPath(); g.rect(i * cw, r * ch, cw, ch); g.clip();
    const ok = drawGeometric(g, ch_, i * cw, r * ch, cw, ch);
    g.restore();
    if (!ok) throw new Error("not handled: " + ch_);
  }));
  const d = g.getImageData(0, 0, W, H).data;
  const ink = new Uint8Array(W * H);
  for (let i = 0; i < W * H; i++) ink[i] = d[i * 4 + 3] >= alphaMin ? 1 : 0;
  return { ink, W, H };
}
const same = (a: Uint8Array, b: Uint8Array) => a.length === b.length && a.every((v, i) => v === b[i]);
const sum = (a: Uint8Array) => a.reduce((s, v) => s + v, 0);
function components(ink: Uint8Array, W: number, H: number) {
  const seen = new Uint8Array(W * H); let n = 0;
  for (let s = 0; s < W * H; s++) if (ink[s] && !seen[s]) {
    n++; const st = [s]; seen[s] = 1;
    while (st.length) { const p = st.pop()!; const x = p % W, y = (p / W) | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; const q = ny * W + nx; if (ink[q] && !seen[q]) { seen[q] = 1; st.push(q); } } }
  }
  return n;
}
const union = (...a: Uint8Array[]) => a[0].map((_, i) => (a.some((x) => x[i]) ? 1 : 0)) as Uint8Array;

for (const cell of [2, 1]) for (const cw of [4, 5, 7, 8, 11, 16, 24, 49]) {
  const ch = cw * cell; const tag = `cw=${cw} ch=${ch}`;
  const one = (c: string) => draw([c], cw, ch).ink;
  const full = one("█");
  // 1. szwy: pelne bloki obok siebie i nad soba daja jednolity prostokat
  const grid = draw(["████", "████", "████"], cw, ch);
  res.push([`${tag} ███ siatka bez szwow`, sum(grid.ink) === grid.W * grid.H, ""]);
  // 2. sumy
  res.push([`${tag} ▀∪▄=█, ▌∪▐=█`, same(union(one("▀"), one("▄")), full) && same(union(one("▌"), one("▐")), full), ""]);
  res.push([`${tag} ▘▝▖▗ = █`, same(union(one("▘"), one("▝"), one("▖"), one("▗")), full), ""]);
  res.push([`${tag} ▙∪▜, ▛∪▟, ▚∪▞ = █`, same(union(one("▙"), one("▜")), full) && same(union(one("▛"), one("▟")), full) && same(union(one("▚"), one("▞")), full), ""]);
  // 3. polowki sasiadujace: ▄ nad ▀ i ▐▌ daja ciaglosc
  const band = draw(["▄▄▄", "▀▀▀"], cw, ch);
  res.push([`${tag} ▄ nad ▀ jedna ciagla wstega`, components(band.ink, band.W, band.H) === 1, ""]);
  const band2 = draw(["▐▌"], cw, ch);
  res.push([`${tag} ▐▌ jedna ciagla wstega`, components(band2.ink, band2.W, band2.H) === 1, ""]);
  // 4. ▁..▇ rosnace wysokosci, monotonicznie
  const hs = "▁▂▃▄▅▆▇█".split("").map((c) => sum(one(c)));
  if (ch >= 16) res.push([`${tag} ▁..█ rosnace`, hs.every((v, i) => i === 0 || v > hs[i - 1]), hs.join(",")]); // ponizej 16 px wysokosci osiem poziomow sie nie rozroznia
  // 5. cieniowanie: gestosc
  if (cw >= 8) { const dn = ["░", "▒", "▓"].map((c) => sum(one(c)) / sum(full));
    res.push([`${tag} ░▒▓ gestosc ~25/50/75%`, Math.abs(dn[0] - 0.25) < 0.05 && Math.abs(dn[1] - 0.5) < 0.05 && Math.abs(dn[2] - 0.75) < 0.05, dn.map((v) => v.toFixed(2)).join("/")]); }
  // 6. ramki: jedna skladowa spojna
  const frames: [string, string[]][] = [
    ["┌─┐│ │└─┘", ["┌─┐", "│ │", "└─┘"]],
    ["siatka ┬┴├┤┼", ["┌┬┐", "├┼┤", "└┴┘"]],
    ["┃ stos", ["┃", "┃", "┃"]],
    ["╪ w stosie │", ["│", "╪", "│"]],
  ];
  for (const [name, f] of frames) { const d = draw(f, cw, ch); res.push([`${tag} ramka ${name}: 1 skladowa`, components(d.ink, d.W, d.H) === 1, String(components(d.ink, d.W, d.H))]); }
  // podwojna ramka: dwa rozlaczne pierscienie (zewnetrzny i wewnetrzny), kazdy ciagly
  const dbl = draw(["╔═╗", "║ ║", "╚═╝"], cw, ch);
  res.push([`${tag} podwojna ramka: 2 pierscienie`, components(dbl.ink, dbl.W, dbl.H) === 2, String(components(dbl.ink, dbl.W, dbl.H))]);
  // luki sa antyaliasowane: cienka (1-2 px) przekatna ma pokrycie ponizej 50%, wiec lacznosc liczymy od alfa >= 16
  const rd = draw(["╭─╮", "│ │", "╰─╯"], cw, ch, 16);
  res.push([`${tag} zaokraglona ramka: 1 skladowa`, components(rd.ink, rd.W, rd.H) === 1, String(components(rd.ink, rd.W, rd.H))]);
}
const fails = res.filter((r) => !r[1]);
console.log(`${res.length - fails.length}/${res.length} OK`);
for (const f of fails) console.log("FAIL", f[0], f[2]);
