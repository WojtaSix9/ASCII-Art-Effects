import { resolveClip } from '../src/clip.ts';
const show = (id: string, r?: any) => { const c = resolveClip(id, r); console.log(id.padEnd(12), JSON.stringify(r ?? {}), '->', c.frames, 'kl', c.seconds.toFixed(3), 's loop', c.loopSeconds, 'looped', c.looped, c.warnings.length ? '| ' + c.warnings.join(' | ') : ''); };
show('cube'); show('cube', { loop: 'exact' }); show('cube', { repeat: 3 }); show('cube', { seconds: 7 }); show('cube', { seconds: 12 });
show('synthwave'); show('donut'); show('tv-static'); show('tv-static', { seconds: 4 }); show('glitch'); show('big-text'); show('big-text', { fps: 30 }); show('big-text', { fps: 24, repeat: 2 });
for (const bad of [() => resolveClip('tv-static', { repeat: 2 }), () => resolveClip('cube', { seconds: 1, repeat: 1 }), () => resolveClip('nie-ma')]) { try { bad(); console.log('BRAK BLEDU'); } catch (e: any) { console.log('blad OK:', e.message); } }
