// Test eksportu MP4 (krok 4.3). Uruchomienie: node --expose-gc scripts/check-mp4.ts
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync, mkdirSync, readdirSync } from 'node:fs';
import { exportMp4 } from '../src/export-video.ts';
import { getScene, rasterizer, renderOptions, ensureFont } from '../src/export-node.ts';
import { ScenePlayer } from '../src/player.ts';

ensureFont();
const TMP = '/tmp/mp4check'; mkdirSync(TMP, { recursive: true });
const res: [string, boolean, string][] = [];
const ok = (n: string, c: boolean, d = '') => res.push([n, c, d]);
const probe = (f: string) => {
  const j = JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-count_frames', '-select_streams', 'v:0', '-show_entries', 'stream=codec_name,pix_fmt,width,height,r_frame_rate,nb_read_frames,duration,color_space,color_range', '-of', 'json', f]).toString());
  const s = j.streams[0]; const [a, b] = s.r_frame_rate.split('/').map(Number);
  return { codec: s.codec_name, pix: s.pix_fmt, w: s.width, h: s.height, fps: a / b, frames: Number(s.nb_read_frames), dur: Number(s.duration), cs: s.color_space, cr: s.color_range };
};
function decodeFrame(f: string, n: number, w: number, h: number): Buffer {
  return execFileSync('ffmpeg', ['-v', 'error', '-i', f, '-vf', `select=eq(n\\,${n}),scale=in_color_matrix=bt709:in_range=tv:out_range=pc,format=rgba`, '-frames:v', '1', '-f', 'rawvideo', '-'], { maxBuffer: 1 << 28 });
}
function psnr(a: Uint8Array, b: Uint8Array) { let se = 0, n = 0; for (let i = 0; i < a.length; i += 4) for (let j = 0; j < 3; j++) { const d = a[i + j] - b[i + j]; se += d * d; n++; } return se === 0 ? 99 : 10 * Math.log10(255 * 255 / (se / n)); }
const sha = (f: string) => createHash('sha1').update(readFileSync(f)).digest('hex').slice(0, 12);
function refFrame(id: string, k: number, o: any) { const { piece, meta } = getScene(id); const ro = renderOptions(meta, o); const b = Buffer.alloc(ro.width * ro.height * 4); rasterizer.renderFrameToBuffer(b, new ScenePlayer(piece, id), meta, k, ro); return b; }

const O = { size: { width: 1280, height: 720 } };
// 1. struktura pliku i liczba klatek (scena, opcje, oczekiwane klatki, fps)
const cases: [string, any, number, number][] = [
  ['cube', {}, 144, 24], ['glitch', {}, 105, 15], ['donut', { seconds: 3 }, 90, 30],
  ['doom-fire', { seconds: 3 }, 72, 24], ['tv-static', {}, 200, 20], ['big-text', { fps: 30 }, 96, 30], ['cube', { repeat: 2 }, 288, 24],
];
const files: string[] = [];
for (const [id, opt, frames, fps] of cases) {
  const f = `${TMP}/${id}-${JSON.stringify(opt).replace(/[^a-z0-9]/gi, '')}.mp4`; files.push(f);
  const r = await exportMp4(id, f, { ...O, ...opt }); const p = probe(f);
  ok(`${id} ${JSON.stringify(opt)}: h264 yuv420p ${p.w}x${p.h} ${frames} klatek ${fps} fps bt709/tv`,
    p.codec === 'h264' && p.pix === 'yuv420p' && p.w === 1280 && p.h === 720 && p.frames === frames && Math.abs(p.fps - fps) < 1e-6 && p.cs === 'bt709' && p.cr === 'tv' && r.clip.frames === frames,
    `klatek ${p.frames}, ${p.dur.toFixed(3)} s, ${(readFileSync(f).length / 1024).toFixed(0)} KB`);
}
// 2. dokladnosc pikseli: zdekodowana klatka vs renderer (PSNR), klatka pierwsza i srodkowa, scena stanowa i bezstanowa
for (const [id, opt, n] of [['cube', {}, 0], ['cube', {}, 70], ['doom-fire', { seconds: 3 }, 40], ['glitch', {}, 50]] as const) {
  const f = files.find((x) => x.includes(`/${id}-${JSON.stringify(opt).replace(/[^a-z0-9]/gi, '')}.mp4`))!;
  const dec = decodeFrame(f, n, 1280, 720); const k = n; const ref = refFrame(id, k, O);
  const q = psnr(dec, ref); ok(`PSNR zdekodowanej klatki ${n} (${id}) vs renderer > 30 dB`, dec.length === ref.length && q > 30, `${q.toFixed(1)} dB`);
}
// 3. mapowanie klatek przy innym fps: donut 30 -> 20 fps (k = round(n*1.5)); klatka wideo 10 -> klatka sceny 15.
//    (big-text odpada: jego sasiednie klatki sa prawie identyczne, wiec taki test nic by nie dowodzil)
{
  const f = `${TMP}/donut-fps20.mp4`; await exportMp4('donut', f, { ...O, seconds: 2, fps: 20 }); const p = probe(f);
  const dec = decodeFrame(f, 10, 1280, 720); const q: Record<number, number> = {};
  for (const k of [13, 14, 15, 16, 17]) q[k] = psnr(dec, refFrame('donut', k, O));
  const best = Object.keys(q).map(Number).sort((a, b) => q[b] - q[a])[0];
  ok('fps 20 ze sceny 30: 40 klatek, a klatka wideo 10 odpowiada klatce sceny 15 (najlepszy PSNR sposrod k=13..17)', p.frames === 40 && Math.abs(p.fps - 20) < 1e-6 && best === 15, `PSNR ${Object.entries(q).map(([k, v]) => `k${k}=${v.toFixed(1)}`).join(' ')}`);
}
// 4. powtarzalnosc: dwa eksporty tej samej sceny
{
  await exportMp4('cube', `${TMP}/cube-rep.mp4`, O); ok('powtarzalnosc: dwa eksporty cube dają ten sam plik bajt w bajt', sha(`${TMP}/cube-rep.mp4`) === sha(files[0]), `${sha(files[0])} / ${sha(`${TMP}/cube-rep.mp4`)}`);
}
// 5. bledy i brak smieci
{
  const thr = async (f: () => Promise<unknown>) => { try { await f(); return false; } catch { return true; } };
  const before = readdirSync(TMP).length;
  ok('blad: tlo przezroczyste', await thr(() => exportMp4('cube', `${TMP}/x1.mp4`, { background: null })));
  ok('blad: nieparzysty rozmiar', await thr(() => exportMp4('cube', `${TMP}/x2.mp4`, { size: { width: 1281, height: 720 } })));
  ok('blad: kolor spoza #hex (sciezka buforowa)', await thr(() => exportMp4('cube', `${TMP}/x3.mp4`, { ...O, ink: 'red' })));
  let msg = ''; try { await exportMp4('cube', `${TMP}/x4.mp4`, { ...O, ffmpeg: '/nie/ma/ffmpeg' }); } catch (e: any) { msg = e.message; }
  ok('blad: brak ffmpeg daje czytelny komunikat', /cannot start ffmpeg/.test(msg), msg.slice(0, 90));
  ok('po bledach brak plikow .mp4/.part', readdirSync(TMP).length === before && !readdirSync(TMP).some((x) => x.endsWith('.part')));
}
const out = res.map(([n, c, d]) => `${c ? 'OK  ' : 'FAIL'} ${n}${d ? '  [' + d + ']' : ''}`).join('\n') + '\n';
mkdirSync('reports', { recursive: true }); writeFileSync('reports/mp4-check.txt', out); console.log(out); console.log(`${res.filter((r) => r[1]).length}/${res.length} OK`);
