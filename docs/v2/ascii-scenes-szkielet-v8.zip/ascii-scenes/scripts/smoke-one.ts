// Test dymny jednej sceny: 2 s do MP4 (1080p) i GIF (480x270), w osobnym procesie. Wynik: jedna linia JSON na stdout.
// Uzycie: node scripts/smoke-one.ts <scena> [sekundy]
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, statSync } from 'node:fs';
import { exportMp4 } from '../src/export-video.ts';
import { exportGif } from '../src/export-gif.ts';
import { parseGif } from '../src/gif-parse.ts';

const id = process.argv[2], seconds = Number(process.argv[3] ?? 2);
const dir = '/tmp/smoke'; mkdirSync(dir, { recursive: true });
let peak = 0; const iv = setInterval(() => { peak = Math.max(peak, process.memoryUsage().rss); }, 100);
const out: Record<string, unknown> = { id }; const problems: string[] = [];
try {
  let t = Date.now(); const m = await exportMp4(id, `${dir}/${id}.mp4`, { seconds }); out.mp4Ms = Date.now() - t;
  const p = JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-count_frames', '-select_streams', 'v:0', '-show_entries', 'stream=codec_name,pix_fmt,width,height,r_frame_rate,nb_read_frames', '-of', 'json', `${dir}/${id}.mp4`]).toString()).streams[0];
  const [a, b] = p.r_frame_rate.split('/').map(Number);
  out.fps = a / b; out.frames = m.clip.frames; out.mp4Kb = Math.round(statSync(`${dir}/${id}.mp4`).size / 1024);
  if (p.codec_name !== 'h264' || p.pix_fmt !== 'yuv420p' || p.width !== 1920 || p.height !== 1080 || Number(p.nb_read_frames) !== m.clip.frames || Math.abs(a / b - m.clip.sceneFps) > 1e-6) problems.push(`mp4 probe: ${JSON.stringify(p)}`);
  t = Date.now(); const g = await exportGif(id, `${dir}/${id}.gif`, { seconds }); out.gifMs = Date.now() - t;
  const gi = parseGif(readFileSync(`${dir}/${id}.gif`)); const sum = gi.delaysCs.reduce((x, y) => x + y, 0);
  out.gifKb = Math.round(statSync(`${dir}/${id}.gif`).size / 1024); out.gifSumCs = sum; out.delays = [...new Set(gi.delaysCs)].join('/');
  if (gi.frames !== m.clip.frames || sum !== Math.round(m.clip.frames * 100 / m.clip.videoFps) || gi.loop !== 0 || gi.width !== 480 || gi.height !== 270) problems.push(`gif: ${gi.frames} frames, ${sum} cs, loop ${gi.loop}, ${gi.width}x${gi.height}`);
  // does it animate, and is it blank?  (decode through ffmpeg, count distinct consecutive frames and colours)
  const raw = execFileSync('ffmpeg', ['-v', 'error', '-i', `${dir}/${id}.gif`, '-f', 'rawvideo', '-pix_fmt', 'rgba', '-'], { maxBuffer: 1 << 30 }); const FS = 480 * 270 * 4;
  let distinct = 1, prev = createHash('md5').update(raw.subarray(0, FS)).digest('hex'); const cols = new Set<number>();
  for (let n = 0; n < raw.length / FS; n++) { const fr = raw.subarray(n * FS, (n + 1) * FS); const h = createHash('md5').update(fr).digest('hex'); if (n && h !== prev) distinct++; prev = h; if (n % 10 === 0) for (let i = 0; i < FS; i += 4) cols.add(fr[i] << 16 | fr[i + 1] << 8 | fr[i + 2]); }
  out.distinctFrames = distinct; out.colors = cols.size;
  if (cols.size < 2) problems.push('blank image (1 colour)');
  const again = await exportGif(id, `${dir}/${id}-2.gif`, { seconds }); void again;
  out.gifRepeat = createHash('sha1').update(readFileSync(`${dir}/${id}.gif`)).digest('hex') === createHash('sha1').update(readFileSync(`${dir}/${id}-2.gif`)).digest('hex');
  if (!out.gifRepeat) problems.push('two GIF exports differ');
  for (const w of m.clip.warnings) out.warn = w.slice(0, 60);
} catch (e) { problems.push(`EXCEPTION ${(e as Error).message.slice(0, 200)}`); }
clearInterval(iv); out.rssMb = Math.round(peak / 1048576); out.problems = problems;
console.log(JSON.stringify(out));
