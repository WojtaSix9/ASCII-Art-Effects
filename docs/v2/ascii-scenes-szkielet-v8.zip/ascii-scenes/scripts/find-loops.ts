// Szuka okresu pętli kazdej sceny: najmniejsze k >= 1 s, dla ktorego okno 2 s od k rowna sie oknu od 0.
import { createHash } from "node:crypto";
import { writeFileSync } from "node:fs";
import { pieces } from "../src/registry.ts";
const hash = (s: string) => createHash("sha1").update(s).digest("hex").slice(0, 10);
const MAX = 180, WINDOW = 2;
const res: Record<string, number | null> = {};
for (const [id, p] of Object.entries(pieces)) {
  const fps = p.meta.fps, W = Math.ceil(WINDOW * fps), N = MAX * fps;
  const f = p.default(); const H: string[] = [];
  for (let k = 0; k <= N + W; k++) H.push(hash(f(k / fps)));
  let found: number | null = null;
  for (let k = Math.ceil(fps); k <= N; k++) {
    let ok = true;
    for (let i = 0; i <= W; i++) if (H[k + i] !== H[i]) { ok = false; break; }
    if (ok) { found = +(k / fps).toFixed(3); break; }
  }
  res[id] = found;
  console.log(id.padEnd(20), found === null ? `brak pętli w ${MAX} s` : `${found} s`);
}
writeFileSync(new URL("../reports/loops.json", import.meta.url), JSON.stringify(res, null, 1));
