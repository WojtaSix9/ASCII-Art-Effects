# Independent GIF decoder for the tests: writes every composited frame as raw RGBA to stdout; prints "n w h" on stderr.
import sys
from PIL import Image, ImageSequence
im = Image.open(sys.argv[1]); n = 0
for fr in ImageSequence.Iterator(im):
    sys.stdout.buffer.write(fr.convert('RGBA').tobytes()); n += 1
sys.stderr.write(f"{n} {im.size[0]} {im.size[1]} loop={im.info.get('loop')}\n")
