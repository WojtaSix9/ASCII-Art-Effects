// Krzywa pamieci przy wielokrotnym uzyciu jednej kanwy. node --expose-gc scripts/mem-curve.ts <scena> <frame|imagedata|data|png|buffer> [klatki]
import { createCanvas } from '@napi-rs/canvas';
import { getScene, rasterizer, ensureFont } from '../src/export-node.ts';
import { ScenePlayer } from '../src/player.ts';
ensureFont();
const id = process.argv[2] ?? 'donut'; const mode = process.argv[3] ?? 'frame'; const N = Number(process.argv[4] ?? 1500);
const { piece, meta } = getScene(id); const pl = new ScenePlayer(piece, id);
const o = { width: 1920, height: 1080, ink: '#7CFFB2', background: '#0a0a0a' };
const c = createCanvas(o.width, o.height); const buf = Buffer.alloc(o.width * o.height * 4);
const mb = () => Math.round(process.memoryUsage().rss / 1048576);
const t0 = performance.now(); let sink = 0;
for (let k = 0; k < N; k++) {
  if (mode === 'buffer') sink += rasterizer.renderFrameToBuffer(buf, pl, meta, k, o)[0]; else rasterizer.renderFrameInto(c, pl, meta, k, o);
  if (mode === 'imagedata') sink += c.getContext('2d').getImageData(0, 0, o.width, o.height).data[0];
  if (mode === 'data') sink += (c as any).data()[0];
  if (mode === 'png') sink += c.toBuffer('image/png').length & 1;
  if (k % 250 === 0) { (globalThis as any).gc?.(); console.log(id, mode, 'k', k, 'RSS', mb(), 'MB'); }
}
console.log(id, mode, 'koniec', N, 'klatek,', ((performance.now() - t0) / N).toFixed(1), 'ms/klatke, RSS', mb(), 'MB');
