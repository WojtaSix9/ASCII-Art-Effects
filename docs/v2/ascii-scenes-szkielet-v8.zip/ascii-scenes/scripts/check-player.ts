// Sprawdza, czy ScenePlayer daje te same klatki przy skokach i cofaniu co przebieg sekwencyjny.
import { createHash } from "node:crypto";
import { pieces } from "../src/registry.ts";
import { ScenePlayer } from "../src/player.ts";
const hash = (s: string) => createHash("sha1").update(s).digest("hex").slice(0, 12);
let bad = 0;
for (const [id, p] of Object.entries(pieces)) {
  const fps = p.meta.fps, N = Math.round(40 * fps);
  const seq = p.default(); const H: string[] = [];
  for (let k = 0; k <= N; k++) H.push(hash(seq(k / fps)));
  const pl = new ScenePlayer(p, id);
  const jumps = [Math.round(2.5 * fps), Math.round(30 * fps), Math.round(0.5 * fps), 0, Math.round(10 * fps), Math.round(10 * fps), N, 3, Math.round(25 * fps)];
  const ok = jumps.every((k) => hash(pl.at(k)) === H[k]);
  if (!ok) bad++;
  console.log(id.padEnd(20), ok ? "ok" : "BLAD");
}
console.log(bad ? `\nBLEDY: ${bad}` : "\nWszystkie 30 scen: skoki i cofanie zgodne z przebiegiem sekwencyjnym");
