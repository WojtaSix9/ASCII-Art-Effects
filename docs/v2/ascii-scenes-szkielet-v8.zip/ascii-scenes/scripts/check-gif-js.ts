// Test enkodera GIF bez zaleznosci od Node (src/gif-js.ts), z klatkami z naszego renderera. Uruchomienie: node scripts/check-gif-js.ts
import { execFileSync, spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, statSync } from 'node:fs';
import { encodeGif } from '../src/gif-js.ts';
import { parseGif, exactDelays } from '../src/gif-parse.ts';
import { exportGif } from '../src/export-gif.ts';
import { resolveClip } from '../src/clip.ts';
import { getScene, rasterizer, renderOptions, ensureFont } from '../src/export-node.ts';
import { ScenePlayer } from '../src/player.ts';

ensureFont(); mkdirSync('/tmp/gifjs', { recursive: true });
const W = 480, H = 270, FS = W * H * 4;
const res: [string, boolean, string][] = []; const ok = (n: string, c: boolean, d = '') => res.push([n, c, d]);
const psnr = (a: Uint8Array, b: Uint8Array) => { let se = 0, n = 0; for (let i = 0; i < a.length; i += 4) for (let j = 0; j < 3; j++) { const d = a[i + j] - b[i + j]; se += d * d; n++; } return se === 0 ? 99 : 10 * Math.log10(65025 / (se / n)); };
const ffDecode = (f: string) => execFileSync('ffmpeg', ['-v', 'error', '-i', f, '-f', 'rawvideo', '-pix_fmt', 'rgba', '-'], { maxBuffer: 1 << 30 });
const pilDecode = (f: string) => { const r = spawnSync('python3', ['scripts/pil-decode.py', f], { maxBuffer: 1 << 30 }); if (r.status !== 0) throw new Error(String(r.stderr)); return r.stdout as Buffer; };
const frameFn = (id: string) => { const { piece, meta } = getScene(id); const ro = renderOptions(meta, { size: { width: W, height: H } }); let p = new ScenePlayer(piece, id); let last = -1; const b = Buffer.alloc(FS);
  return (n: number) => { if (n <= last) { p = new ScenePlayer(piece, id); last = -1; } last = n; const clip = null; void clip; rasterizer.renderFrameToBuffer(b, p, meta, n, ro); return b; }; };

for (const [id, opt] of [['cube', {}], ['glitch', {}], ['doom-fire', { seconds: 2 }], ['donut', { seconds: 2 }], ['tv-static', { seconds: 4 }], ['big-text', { fps: 25 }]] as [string, any][]) {
  const clip = resolveClip(id, opt); const rawFn = frameFn(id); const sceneFps = clip.sceneFps, vfps = clip.videoFps;
  const fn = (n: number) => rawFn(Math.round(n * sceneFps / vfps));
  let t = Date.now(); const r = encodeGif({ width: W, height: H, frames: clip.frames, fps: vfps, frame: fn }); const ms = Date.now() - t;
  const f = `/tmp/gifjs/${id}.gif`; writeFileSync(f, r.bytes); const g = parseGif(readFileSync(f));
  const sum = g.delaysCs.reduce((a, b) => a + b, 0);
  ok(`${id}: struktura (${clip.frames} klatek, ${W}x${H}, petla nieskonczona, suma opoznien = round(n*100/fps))`, g.frames === clip.frames && g.width === W && g.height === H && g.loop === 0 && sum === Math.round(clip.frames * 100 / vfps) && g.delaysCs.join() === exactDelays(clip.frames, vfps).join(), `${(r.bytes.length / 1024).toFixed(0)} KB, ${ms} ms, paleta ${r.paletteSize}${r.exact ? ' dokladna' : ' kwantyzowana'}`);
  const a = ffDecode(f), b = pilDecode(f); const rf = frameFn(id); let min = 99;
  for (let n = 0; n < clip.frames; n++) { const ref = Buffer.from(rf(Math.round(n * sceneFps / vfps))); min = Math.min(min, psnr(a.subarray(n * FS, (n + 1) * FS), ref)); }
  ok(`${id}: ffmpeg i Pillow dekoduja identycznie, kazda klatka zgodna z rendererem (PSNR > 60 dB = bez strat)`, a.length === clip.frames * FS && Buffer.compare(a, b) === 0 && min > 60, `min PSNR ${min.toFixed(1)} dB`);
  const ffp = `/tmp/gifjs/${id}-ffmpeg.gif`; await exportGif(id, ffp, opt); const ffs = statSync(ffp).size;
  ok(`${id}: rozmiar vs ffmpeg (informacyjnie)`, true, `JS ${(r.bytes.length / 1024).toFixed(0)} KB, ffmpeg ${(ffs / 1024).toFixed(0)} KB, stosunek ${(r.bytes.length / ffs).toFixed(2)}`);
  const r2 = encodeGif({ width: W, height: H, frames: clip.frames, fps: vfps, frame: fn }); ok(`${id}: powtarzalnosc (dwa przebiegi identyczne)`, Buffer.compare(Buffer.from(r2.bytes), Buffer.from(r.bytes)) === 0);
}
{ // kwantyzacja: donut przy 16 kolorach (zrodlo ma ok. 115)
  const clip = resolveClip('donut', { seconds: 1 }); const fn = frameFn('donut'); const r = encodeGif({ width: W, height: H, frames: clip.frames, fps: clip.videoFps, frame: fn, maxColors: 16 });
  writeFileSync('/tmp/gifjs/q16.gif', r.bytes); const a = ffDecode('/tmp/gifjs/q16.gif'); const cols = new Set<number>(); for (let i = 0; i < a.length; i += 4) cols.add(a[i] << 16 | a[i + 1] << 8 | a[i + 2]);
  const rf = frameFn('donut'); let sum = 0; for (let n = 0; n < clip.frames; n++) sum += psnr(a.subarray(n * FS, (n + 1) * FS), Buffer.from(rf(n)));
  ok('maxColors 16 (kwantyzator): nie wiecej niz 16 kolorow, obraz nie pusty', !r.exact && cols.size <= 16 && cols.size > 2, `${cols.size} kolorow, sredni PSNR ${(sum / clip.frames).toFixed(1)} dB, ${(r.bytes.length / 1024).toFixed(0)} KB`);
  let thrown = 0; for (const mc of [1, 257, 1.5]) try { encodeGif({ width: W, height: H, frames: 1, fps: 10, frame: fn, maxColors: mc }); } catch { thrown++; } ok('bledne maxColors rzuca blad', thrown === 3);
  const one = encodeGif({ width: W, height: H, frames: 1, fps: 10, frame: fn }); const g1 = parseGif(Buffer.from(one.bytes)); ok('jedna klatka: poprawny GIF, bez przezroczystosci', g1.frames === 1 && g1.transparentFrames === 0 && g1.delaysCs[0] === 10);
}
{ const src = readFileSync('src/gif-js.ts', 'utf8'); ok('gif-js.ts nie importuje nic z Node (node:, fs, Buffer)', !/from 'node:|require\(|Buffer|process\./.test(src.replace(/\/\/.*$/gm, '')));
  const pg = readFileSync('src/gif-parse.ts', 'utf8'); ok('uwaga: gif-parse.ts (importowane dla exactDelays) uzywa typu Buffer, ale tylko w parserze testowym', /Buffer/.test(pg)); }
const out = res.map(([n, c, d]) => `${c ? 'OK  ' : 'FAIL'} ${n}${d ? '  [' + d + ']' : ''}`).join('\n') + '\n'; writeFileSync('reports/gif-js-check.txt', out); console.log(out); console.log(`${res.filter((r) => r[1]).length}/${res.length} OK`);
