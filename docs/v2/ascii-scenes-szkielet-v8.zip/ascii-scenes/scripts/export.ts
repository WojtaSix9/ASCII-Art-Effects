// CLI: node scripts/export.ts <scene> <png|txt|mp4|gif> [--k N] [--out plik] [--ink #hex] [--bg #hex|transparent] [--size 1920x1080 | --cell 24]
//      mp4: [--seconds N | --repeat N] [--loop exact|recommended] [--fps N] [--crf N]
//      node scripts/export.ts --list
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { exportPng, exportText, sceneIds } from '../src/export-node.ts';
import { exportMp4 } from '../src/export-video.ts';
import { exportGif } from '../src/export-gif.ts';
import type { FrameOptions } from '../src/export-node.ts';

const args = process.argv.slice(2);
if (args.includes('--list') || args.length < 2) {
  console.log(args.includes('--list') ? sceneIds().join('\n') : 'uzycie: node scripts/export.ts <scena> <png|txt> [--k N] [--out plik] [--ink #hex] [--bg #hex|transparent] [--size WxH | --cell N]   (lista scen: --list)');
  process.exit(args.includes('--list') ? 0 : 1);
}
const [scene, format] = args;
const opt = (name: string) => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : undefined; };
const k = Number(opt('--k') ?? 0);
const o: FrameOptions = {};
if (opt('--ink')) o.ink = opt('--ink');
if (opt('--bg')) o.background = opt('--bg') === 'transparent' ? null : opt('--bg');
if (opt('--size')) { const m = /^(\d+)x(\d+)$/.exec(opt('--size')!); if (!m) throw new Error('--size WxH'); o.size = { width: +m[1], height: +m[2] }; }
if (opt('--cell')) o.size = { cellPx: Number(opt('--cell')) };
const out = opt('--out') ?? `out/${scene}-k${k}.${format}`;
mkdirSync(dirname(out), { recursive: true });
if (format === 'png') writeFileSync(out, exportPng(scene, k, o));
else if (format === 'txt') writeFileSync(out, exportText(scene, k));
else if (format === 'mp4') {
  const num = (n: string) => (opt(n) !== undefined ? Number(opt(n)) : undefined);
  const r = await exportMp4(scene, out, { ...o, seconds: num('--seconds'), repeat: num('--repeat'), fps: num('--fps'), crf: num('--crf'), loop: opt('--loop') as any,
    onProgress: (d, t) => process.stderr.write(`\r${d}/${t} klatek`) });
  process.stderr.write('\n');
  for (const w of r.clip.warnings) console.warn('uwaga:', w);
  console.log(`${r.clip.frames} klatek, ${r.clip.seconds.toFixed(3)} s, ${r.clip.videoFps} fps, ${r.width}x${r.height}, petla: ${r.clip.looped ? 'tak' : 'nie'}`);
} else if (format === 'gif') {
  const num = (n: string) => (opt(n) !== undefined ? Number(opt(n)) : undefined);
  const r = await exportGif(scene, out, { ...o, seconds: num('--seconds'), repeat: num('--repeat'), fps: num('--fps'), loop: opt('--loop') as any, maxColors: num('--colors'),
    onProgress: (d, t) => process.stderr.write(`\r${d}/${t} klatek`) });
  process.stderr.write('\n');
  for (const w of r.warnings) console.warn('uwaga:', w);
  console.log(`${r.clip.frames} klatek, ${r.clip.seconds.toFixed(3)} s, ${r.clip.videoFps} fps, ${r.width}x${r.height}, petla: ${r.clip.looped ? 'tak' : 'nie'}`);
} else throw new Error('format: png, txt, mp4 albo gif');
console.log('zapisano', out);
