// Dlugi GIF: pamiec i czas. Uruchomienie: node scripts/long-gif.ts [scena] [sekundy]
import { statSync } from 'node:fs';
import { exportGif } from '../src/export-gif.ts';
import { parseGif } from '../src/gif-parse.ts';
import { readFileSync } from 'node:fs';
const id = process.argv[2] ?? 'donut', seconds = Number(process.argv[3] ?? 15);
let peak = 0; const t = setInterval(() => { peak = Math.max(peak, process.memoryUsage().rss); }, 200);
const t0 = Date.now(); const r = await exportGif(id, `/tmp/long-${id}.gif`, { seconds });
clearInterval(t); const g = parseGif(readFileSync(r.path));
console.log(`${id} ${seconds} s: ${g.frames} klatek, suma ${g.delaysCs.reduce((a, b) => a + b, 0)} cs, ${(statSync(r.path).size / 1048576).toFixed(2)} MB, ${((Date.now() - t0) / 1000).toFixed(1)} s, szczytowe RSS Node ${(peak / 1048576).toFixed(0)} MB`);
