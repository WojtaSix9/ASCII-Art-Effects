// Wyszukiwanie petli z tolerancja (krok 2b). Uruchomienie: node scripts/find-loops-tol.ts <id> [maxSeconds]
// Wynik: reports/loops-tol.d/<id>.json. Scena jest odtwarzana przez ScenePlayer, kolejno od klatki 0.
//
// Odleglosc klatek d(a,b) = ulamek komorek o roznym znaku (0 = identyczne, 1 = wszystko inne).
// Kandydat na petle dlugosci T = k/fps: okno W = WS s (domyslnie 4 s; 1 s bylo za krotkie dla scen zmieniajacych sie co ok. sekunde, np. typewriter) od klatki k porownane z oknem od klatki 0
//   windowDist(k) = srednia d(klatka(k+i), klatka(i)), i = 0..W   (faza ruchu musi sie zgadzac, nie tylko poza)
// Odniesienia: step = srednia d(klatka(i), klatka(i+1)) w calym przebiegu; localStep = to samo w oknie 0..W (poczatek sceny);
// unrelated = srednia d dla klatek z roznych momentow.
// Klasy:
//   A "petla":  windowDist <= 0.5 * localStep  (roznica okien nie wieksza niz polowa zwyklego kroku w tym miejscu; 0 = dokladna;
//               przy nieruchomym poczatku, localStep = 0, wymagana jest dokladna rownosc)
//   Progi ratio = windowDist / localStep: S <= 0.25 (rekomendowana, klasa "A"), <= 0.5 (graniczna, klasa "A?": czesto losowa zbieznosc, np. synthwave 3.35 s), <= 1.0 (tierB).
//   B "szum":   step >= 0.8 * unrelated   (kolejne klatki sa juz tak rozne jak dowolne dwie: dowolne ciecie jest niewidoczne)
//   C "brak":   reszta; uzyj dlugosci klipu
import { mkdirSync, writeFileSync } from "node:fs";
import { pieces } from "../src/registry.ts";
import { ScenePlayer } from "../src/player.ts";

const id = process.argv[2]; const MAX = Number(process.argv[3] ?? 180); const WS = Number(process.argv[4] ?? 4); // okno w sekundach
const piece = pieces[id]; const fps = piece.meta.fps;
const W = Math.ceil(WS * fps), N = Math.round(MAX * fps), TOTAL = N + W + 1;
const player = new ScenePlayer(piece, id);
const t0 = performance.now();
const F: Uint16Array[] = [];
for (let k = 0; k < TOTAL; k++) {
  const s = player.at(k).replace(/\n/g, "");
  const a = new Uint16Array(s.length); for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i);
  F.push(a);
}
const n = F[0].length;
const dist = (a: Uint16Array, b: Uint16Array) => { let c = 0; for (let i = 0; i < n; i++) if (a[i] !== b[i]) c++; return c / n; };

let step = 0; for (let i = 0; i + 1 < TOTAL; i++) step += dist(F[i], F[i + 1]); step /= TOTAL - 1;
let unrelated = 0, m = 0;
for (let q = 0; q < 300; q++) { const i = (q * 7919) % TOTAL, j = (q * 104729 + 13) % TOTAL; if (Math.abs(i - j) >= 5 * fps) { unrelated += dist(F[i], F[j]); m++; } }
unrelated /= Math.max(1, m);

let localStep = 0; for (let i = 0; i < W; i++) localStep += dist(F[i], F[i + 1]); localStep /= W;
const winDist = (k: number) => { let s = 0; for (let i = 0; i <= W; i++) s += dist(F[k + i], F[i]); return s / (W + 1); };
const winMax = (k: number) => { let s = 0; for (let i = 0; i <= W; i++) s = Math.max(s, dist(F[k + i], F[i])); return s; };
// Okno liczone dla KAZDEGO k (bez heurystyki kandydatow: plateau identycznych klatek wypychalo z listy prawdziwe petle).
const kMin = Math.ceil(fps);
const WD: number[] = [], WM: number[] = [];
for (let k = kMin; k <= N; k++) { WD[k] = winDist(k); WM[k] = winMax(k); }
const ratio = (k: number) => localStep > 0 ? WD[k] / localStep : (WD[k] === 0 ? 0 : Infinity);
// pierwszy k spelniajacy prog, potem doprecyzowanie: najlepsze dopasowanie w kolejnych 3 klatkach (lokalne minimum fazy)
const firstWithin = (thr: number) => {
  for (let k = kMin; k <= N; k++) if (ratio(k) <= thr) {
    let b = k; for (let j = k; j <= Math.min(N, k + 3); j++) if (WD[j] < WD[b]) b = j; return b;
  }
  return null;
};
const info = (k: number | null) => k === null ? null : { k, seconds: +(k / fps).toFixed(3), windowDist: +WD[k].toFixed(5), windowMax: +WM[k].toFixed(5), ratio: +ratio(k).toFixed(3), seamMismatch: +dist(F[k], F[0]).toFixed(5), naturalStep: +dist(F[k - 1], F[k]).toFixed(5), seamRatio: +(dist(F[k], F[0]) / Math.max(dist(F[k - 1], F[k]), 1 / n)).toFixed(3) };
// seamMismatch = d(F[T],F[0]): o tyle klatka po szwie rozni sie od tej, ktora scena pokazalaby naturalnie; naturalStep = d(F[T-1],F[T]); seamRatio = ich iloraz (< 1: szew mniejszy niz zwykly krok w tym miejscu)
const tierS = firstWithin(0.25), tierA = firstWithin(0.5), tierB = firstWithin(1.0);
// najlepsze dopasowanie w ogole, plus kilka lokalnych minimow oddalonych o >= 1 s
const order = Array.from({ length: N - kMin + 1 }, (_, i) => i + kMin).sort((x, y) => WD[x] - WD[y]);
const best5: number[] = []; for (const k of order) { if (best5.every((q) => Math.abs(q - k) >= fps)) best5.push(k); if (best5.length === 5) break; }
const cls = tierS !== null ? "A" : tierA !== null ? "A?" : step >= 0.8 * unrelated ? "B" : "C";
mkdirSync("reports/loops-tol.d", { recursive: true });
writeFileSync(`reports/loops-tol.d/${id}.json`, JSON.stringify({
  id, fps, cells: n, maxSeconds: MAX, windowSeconds: WS, windowFrames: W + 1, step: +step.toFixed(5), localStep: +localStep.toFixed(5), unrelated: +unrelated.toFixed(5), class: cls,
  tierS: info(tierS), tierA: info(tierA), tierB: info(tierB), best5: best5.map(info), computeSeconds: +((performance.now() - t0) / 1000).toFixed(1),
}));
const show = (c: any) => c ? `T=${c.seconds}s ratio=${c.ratio} win=${c.windowDist}` : "-";
console.log(`${cls} ${id.padEnd(20)} step=${step.toFixed(4)} local=${localStep.toFixed(4)} unrel=${unrelated.toFixed(4)} S:${show(info(tierS))} | A:${show(info(tierA))} | B:${show(info(tierB))} | best:${show(info(best5[0]))}`);
