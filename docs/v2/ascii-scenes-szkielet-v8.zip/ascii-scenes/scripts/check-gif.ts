// Test eksportu GIF (krok 4.4). Uruchomienie: node --expose-gc scripts/check-gif.ts
import { execFileSync, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync } from 'node:fs';
import { exportGif, GIF_DEFAULT_SIZE } from '../src/export-gif.ts';
import { parseGif, exactDelays, setGifDelays } from '../src/gif-parse.ts';
import { getScene, rasterizer, renderOptions, ensureFont } from '../src/export-node.ts';
import { ScenePlayer } from '../src/player.ts';

ensureFont();
const TMP = '/tmp/gifcheck'; mkdirSync(TMP, { recursive: true });
const res: [string, boolean, string][] = [];
const ok = (n: string, c: boolean, d = '') => res.push([n, c, d]);
const sha = (f: string) => createHash('sha1').update(readFileSync(f)).digest('hex').slice(0, 12);
const kb = (f: string) => `${(statSync(f).size / 1024).toFixed(0)} KB`;
const W = GIF_DEFAULT_SIZE.width, H = GIF_DEFAULT_SIZE.height, FS = W * H * 4;
function psnr(a: Uint8Array, b: Uint8Array) { let se = 0, n = 0; for (let i = 0; i < a.length; i += 4) for (let j = 0; j < 3; j++) { const d = a[i + j] - b[i + j]; se += d * d; n++; } return se === 0 ? 99 : 10 * Math.log10(255 * 255 / (se / n)); }
const ffDecode = (f: string) => execFileSync('ffmpeg', ['-v', 'error', '-i', f, '-f', 'rawvideo', '-pix_fmt', 'rgba', '-'], { maxBuffer: 1 << 30 });
function pilDecode(f: string) { const r = spawnSync('python3', ['scripts/pil-decode.py', f], { maxBuffer: 1 << 30 }); if (r.status !== 0) throw new Error(String(r.stderr)); return { data: r.stdout as Buffer, info: String(r.stderr).trim() }; }
function refFrames(id: string, ks: number[], size = { width: W, height: H }) {
  const { piece, meta } = getScene(id); const ro = renderOptions(meta, { size }); const p = new ScenePlayer(piece, id); const out: Buffer[] = [];
  for (const k of ks) { const b = Buffer.alloc(ro.width * ro.height * 4); rasterizer.renderFrameToBuffer(b, p, meta, k, ro); out.push(b); } return out;
}

// 1. struktura, opoznienia i dlugosc petli: po jednej scenie z kazdego fps wystepujacego w 30 scenach (15, 20, 24, 30) + fps zmienione
const cases: [string, any][] = [['cube', {}], ['glitch', {}], ['synthwave', {}], ['big-text', {}], ['tv-static', { seconds: 4 }], ['donut', { seconds: 2 }], ['doom-fire', { seconds: 2 }], ['big-text', { fps: 25 }]];
const files = new Map<string, string>();
for (const [id, opt] of cases) {
  const f = `${TMP}/${id}-${JSON.stringify(opt).replace(/[^a-z0-9]/gi, '')}.gif`; files.set(id + JSON.stringify(opt), f);
  const r = await exportGif(id, f, opt); const g = parseGif(readFileSync(f));
  const fps = r.clip.videoFps, sum = g.delaysCs.reduce((a, b) => a + b, 0), want = Math.round(r.clip.frames * 100 / fps);
  const lo = Math.min(...g.delaysCs), hi = Math.max(...g.delaysCs), even = lo === hi;
  const hist: Record<number, number> = {}; g.delaysCs.forEach((d) => (hist[d] = (hist[d] ?? 0) + 1));
  ok(`${id} ${JSON.stringify(opt)}: ${r.clip.frames} klatek, ${W}x${H}, ${fps} fps, petla nieskonczona, paleta <= 256`,
    g.frames === r.clip.frames && g.width === W && g.height === H && g.loop === 0 && g.globalColors <= 256 && g.localPaletteFrames <= 1 && r.delaysCs.join() === g.delaysCs.join(),
    `${g.frames} klatek, ${kb(f)}, paleta globalna ${g.globalColors}, lokalnych ${g.localPaletteFrames}`);
  ok(`${id} ${JSON.stringify(opt)}: suma opoznien = round(klatki*100/fps) = ${want} cs (dlugosc petli bez dryfu)`, sum === want, `suma ${sum} cs, klip ${(r.clip.frames / fps).toFixed(3)} s, GIF ${(sum / 100).toFixed(2)} s`);
  ok(`${id} ${JSON.stringify(opt)}: opoznienia rowne albo roznia sie o 1 cs (${fps} fps)`, hi - lo <= 1 && (100 / fps !== Math.round(100 / fps) || even), `histogram cs: ${JSON.stringify(hist)}${even ? ' (rowne)' : ' (nierowne)'}`);
}

// 2. exactDelays i setGifDelays na fps niecalkowitych i pograniczu (8 fps dawalo w ffmpeg 201 cs zamiast 200)
{
  const sums = [8, 12, 15, 24, 30, 7, 14.5].map((fps) => [fps, exactDelays(fps * 10 | 0 || 1, fps).reduce((a, b) => a + b, 0), Math.round((fps * 10 | 0) * 100 / fps)]);
  ok('exactDelays: suma = round(n*100/fps) dla 8, 12, 15, 24, 30, 7, 14.5 fps', sums.every(([, s, w]) => s === w), sums.map(([f, s]) => `${f}fps:${s}`).join(' '));
  const f = files.get('cube{}')!; const copy = Buffer.from(readFileSync(f)); const g0 = parseGif(copy);
  setGifDelays(copy, g0.delaysCs.map(() => 7)); const g1 = parseGif(copy);
  ok('setGifDelays: nadpisuje opoznienia, nie psuje struktury', g1.frames === g0.frames && g1.delaysCs.every((d) => d === 7) && g1.loop === 0);
  let thrown = false; try { setGifDelays(Buffer.from(readFileSync(f)), [1, 2]); } catch { thrown = true; } ok('setGifDelays: zla liczba opoznien rzuca blad', thrown);
}

// 3. dokladnosc pikseli: dwa niezalezne dekodery (ffmpeg, Pillow) vs renderer, wszystkie klatki
for (const [id, opt, n] of [['cube', {}, 144], ['doom-fire', { seconds: 2 }, 48], ['donut', { seconds: 2 }, 60]] as [string, any, number][]) {
  const f = files.get(id + JSON.stringify(opt))!;
  const a = ffDecode(f), b = pilDecode(f); const refs = refFrames(id, Array.from({ length: n }, (_, i) => i));
  ok(`${id}: ffmpeg i Pillow dekoduja ${n} klatek identycznie (przezroczystosc miedzyklatkowa poprawna)`, a.length === n * FS && b.data.length === n * FS && Buffer.compare(a, b.data) === 0, `Pillow: ${b.info}`);
  const uc = new Set<number>(); for (let i = 0; i < a.length; i += 4) uc.add(a[i] << 16 | a[i + 1] << 8 | a[i + 2]);
  ok(`${id}: liczba unikalnych kolorow w renderze zrodlowym <= 256 (stad bitowa zgodnosc)`, (() => { const s2 = new Set<number>(); for (const r of refs) for (let i = 0; i < r.length; i += 4) s2.add(r[i] << 16 | r[i + 1] << 8 | r[i + 2]); return s2.size <= 256; })(), `GIF ${uc.size} kolorow`);
  let min = 99, sum = 0; for (let i = 0; i < n; i++) { const q = psnr(a.subarray(i * FS, (i + 1) * FS), refs[i]); min = Math.min(min, q); sum += q; }
  ok(`${id}: PSNR kazdej klatki GIF vs renderer > 30 dB`, min > 30, `min ${min.toFixed(1)} dB, srednio ${(sum / n).toFixed(1)} dB`);
}

// 4. mapowanie klatek przy innym fps: donut 30 -> 20 fps (k = round(n*1.5)); klatka GIF 10 odpowiada klatce sceny 15.
//    (cube odpada: jego sasiednie klatki sa identyczne, wiec taki test nic by nie rozroznial)
{
  const f = `${TMP}/donut-fps20.gif`; await exportGif('donut', f, { seconds: 2, fps: 20 }); const g = parseGif(readFileSync(f)); const dec = ffDecode(f); const ks = [13, 14, 15, 16, 17]; const refs = refFrames('donut', ks);
  const q = refs.map((r) => psnr(dec.subarray(10 * FS, 11 * FS), r)); const best = ks[q.indexOf(Math.max(...q))];
  ok('fps 20 ze sceny 30: 40 klatek, klatka GIF 10 = klatka sceny 15, opoznienia rowne 5 cs', g.frames === 40 && best === 15 && g.delaysCs.every((d) => d === 5), `PSNR ${q.map((v, i) => `k${ks[i]}=${v.toFixed(1)}`).join(' ')}`);
}

// 5. powtarzalnosc
{ const f1 = files.get('cube{}')!, f2 = `${TMP}/cube-rep.gif`; await exportGif('cube', f2, {}); ok('powtarzalnosc: dwa eksporty cube dają ten sam plik bajt w bajt', sha(f1) === sha(f2), `${sha(f1)} / ${sha(f2)}`); }

// 6. opcje: kolor, tlo, maxColors, rozmiar nieparzysty, wlasny rozmiar
{
  const f = `${TMP}/opts.gif`; const r = await exportGif('big-text', f, { ink: '#ff8800', background: '#102030', maxColors: 16, size: { width: 301, height: 151 }, seconds: 1 });
  const g = parseGif(readFileSync(f)); const dec = ffDecode(f); const cols = new Set<number>(); for (let i = 0; i < dec.length; i += 4) cols.add(dec[i] << 16 | dec[i + 1] << 8 | dec[i + 2]);
  ok('opcje: ink, background, maxColors 16, rozmiar 301x151 (nieparzysty), 24 klatki', g.width === 301 && g.height === 151 && g.frames === 24 && dec.length === 24 * 301 * 151 * 4 && cols.size <= 16 && cols.has(0x102030), `unikalnych kolorow w calym GIF-ie ${cols.size} (tablica palety w pliku: ${g.globalColors}, ffmpeg dopelnia do 256)`);
  const f2 = `${TMP}/opts2.gif`; await exportGif('donut', f2, { maxColors: 8, seconds: 1 }); const d2 = ffDecode(f2); const c2 = new Set<number>(); for (let i = 0; i < d2.length; i += 4) c2.add(d2[i] << 16 | d2[i + 1] << 8 | d2[i + 2]);
  ok('maxColors 8 na donut (115 kolorow w zrodle): najwyzej 8, wiecej niz 2', c2.size <= 8 && c2.size > 2, `${c2.size} kolorow, ${(statSync(f2).size / 1024).toFixed(0)} KB`);
}

// 7. bledy i brak smieci
{
  const thr = async (f: () => Promise<unknown>) => { try { await f(); return false; } catch { return true; } };
  const before = readdirSync(TMP).length;
  ok('blad: tlo przezroczyste', await thr(() => exportGif('cube', `${TMP}/x1.gif`, { background: null })));
  ok('blad: maxColors 1 i 300', await thr(() => exportGif('cube', `${TMP}/x2.gif`, { maxColors: 1 })) && await thr(() => exportGif('cube', `${TMP}/x3.gif`, { maxColors: 300 })));
  ok('blad: kolor spoza #hex (sciezka buforowa)', await thr(() => exportGif('cube', `${TMP}/x4.gif`, { ink: 'red' })));
  ok('blad: nieznana scena', await thr(() => exportGif('nie-ma', `${TMP}/x5.gif`)));
  let msg = ''; try { await exportGif('cube', `${TMP}/x6.gif`, { ffmpeg: '/nie/ma/ffmpeg' }); } catch (e: any) { msg = e.message; }
  ok('blad: brak ffmpeg daje czytelny komunikat', /cannot start ffmpeg/.test(msg), msg.slice(0, 90));
  ok('po bledach brak nowych plikow i .part', readdirSync(TMP).length === before && !readdirSync(TMP).some((x) => x.endsWith('.part')));
}

// 8. limit 10 s i ostrzezenia
{
  const thr = async (f: () => Promise<unknown>) => { try { await f(); return false; } catch (e) { return /limited to 10 s/.test((e as Error).message); } };
  ok('limit: jawne seconds 10,5 i repeat dajace > 10 s rzucaja blad', await thr(() => exportGif('big-text', `${TMP}/l1.gif`, { seconds: 10.5 })) && await thr(() => exportGif('cube', `${TMP}/l2.gif`, { repeat: 2 })));
  const r0 = await exportGif('big-text', `${TMP}/l3.gif`, { seconds: 10 }); ok('limit: dokladnie 10 s przechodzi (240 klatek)', r0.clip.frames === 240 && parseGif(readFileSync(`${TMP}/l3.gif`)).delaysCs.reduce((a, b) => a + b, 0) === 1000);
  const r1 = await exportGif('donut', `${TMP}/l4.gif`); const g1 = parseGif(readFileSync(`${TMP}/l4.gif`));
  ok('limit: domyslna petla 125,7 s (donut) ucieta do 10 s = 300 klatek, z ostrzezeniem', r1.clip.frames === 300 && g1.frames === 300 && g1.delaysCs.reduce((a, b) => a + b, 0) === 1000 && r1.warnings.some((w) => /exceeds the GIF limit/.test(w)), `${r1.warnings.join(' | ').slice(0, 150)}; ${kb(`${TMP}/l4.gif`)}`);
  const r2 = await exportGif('synthwave', `${TMP}/l5.gif`); ok('limit: petla 10 s (synthwave) nie jest ucinana ani ostrzegana o limicie', r2.clip.frames === 200 && r2.clip.looped && !r2.warnings.some((w) => /limit/.test(w)));
  const r3 = await exportGif('big-text', `${TMP}/w2.gif`, { fps: 25 }); ok('ostrzezenie o dryfie petli przy zmienionym fps (big-text 24 -> 25, 3,208 s = 80,2 klatki)', r3.warnings.some((w) => /drifts/.test(w)), r3.warnings.join(' | ').slice(0, 140));
}

const out = res.map(([n, c, d]) => `${c ? 'OK  ' : 'FAIL'} ${n}${d ? '  [' + d + ']' : ''}`).join('\n') + '\n';
mkdirSync('reports', { recursive: true }); writeFileSync('reports/gif-check.txt', out); console.log(out); console.log(`${res.filter((r) => r[1]).length}/${res.length} OK`);
