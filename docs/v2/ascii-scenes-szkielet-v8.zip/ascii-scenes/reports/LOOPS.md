# Pętle z tolerancją (krok 2b)

Źródło danych: `reports/loops-tol.json` (z `scripts/find-loops-tol.ts`, `find-loops-tol-all.sh`). Wszystko `test`, Node 22.22, opcje domyślne, przebieg 0–180 s przez `ScenePlayer`.

## Metoda (proj)
- Odległość klatek `d` = ułamek komórek o różnym znaku (0 = identyczne). Nie waży różnic tonalnych (`.` vs `@` liczy tak samo jak `.` vs `,`).
- Kandydat T = k / fps. Okno 4 s od klatki k porównane z oknem od klatki 0: `windowDist` = średnie `d(klatka(k+i), klatka(i))`. Okno (nie sama poza) wymusza zgodność fazy ruchu. Okno 1 s było za krótkie: typewriter dawał fałszywą „dokładną” pętlę 115,7 s (różnica pojawia się dopiero po 1,15 s).
- `ratio` = windowDist / localStep, gdzie localStep to średni krok między kolejnymi klatkami w tym samym oknie. Interpretacja: ratio 0,5 ≈ półklatkowy błąd fazy, czyli naturalna granica dla okresu niecałkowitego w klatkach.
- **Rekomendowana pętla:** najkrótsze T z ratio ≤ 0,25. Graniczna: ≤ 0,5 (bywa przypadkowa: synthwave 3,35 s). Dokładna (ratio 0) tylko, gdy test tego dowodzi.
- Szew: `seamRatio` = d(klatka T, klatka 0) / d(klatka T−1, klatka T): o ile klatka po szwie różni się od tej, którą scena pokazałaby naturalnie, względem zwykłego kroku w tym miejscu. Dla pętli jednego klipu liczy się szew, nie to, że scena jest okresowa w nieskończoność.
- Klasa A = jest rekomendowana pętla; A? = tylko graniczna; B = szum (kroki tak duże jak różnice dowolnych klatek); C = brak pętli.

## Kontrola metody: 9 scen z dokładną pętlą
Wszystkie 9 okresów dokładnych odzyskane jako najlepsze dopasowanie (windowDist = 0): plasma 30 s, mandelbrot 48 s, voronoi 30 s, cube 18 s, wave-interference 90 s, big-text 16 s, glitch 7 s, wave-text 57 s, scramble 121,15 s. Tolerancja znajduje też okresy bazowe, z których te się składają:

| scena | dokładna | rekomendowana (ratio) |
|---|---|---|
| plasma | 30 s | 30 s (0) |
| mandelbrot | 48 s | 48 s (0) |
| voronoi | 30 s | 30 s (0) |
| cube | 18 s | 6 s (0.019) |
| wave-interference | 90 s | 90 s (0) |
| big-text | 16 s | 3.208 s (0.206) |
| glitch | 7 s | 7 s (0) |
| wave-text | 57 s | 7.133 s (0.123) |
| scramble | 121.15 s | 13.45 s (0.044) |

## 21 scen bez dokładnej pętli

| scena | klasa | rekomendowana | ratio | szew/krok | najlepsze w ogóle |
|---|---|---|---|---|---|
| doom-fire | C | — | — | — | 112.292 s (ratio 1.857) |
| matrix-rain | C | — | — | — | 25.95 s (ratio 5.219) |
| tunnel | C | — | — | — | 91.667 s (ratio 1.144) |
| tv-static | C | — | — | — | 110 s (ratio 0.946) |
| synthwave | A | 10 s | 0.111 | 0.032 | 120 s (ratio 0.066) |
| fireworks | C | — | — | — | 26.167 s (ratio 3.001) |
| reaction-diffusion | C | — | — | — | 1 s (ratio 4.972) |
| flow-field | C | — | — | — | 1 s (ratio 10.992) |
| donut | A | 125.667 s | 0.184 | 0.165 | 125.667 s (ratio 0.184) |
| tesseract | A | 35.9 s | 0.211 | 0.55 | 161.567 s (ratio 0.069) |
| torus-knot | A | 125.667 s | 0.151 | 0.121 | 125.667 s (ratio 0.151) |
| dna-helix | A | 37.7 s | 0.026 | 0 | 37.7 s (ratio 0.026) |
| rain | C | — | — | — | 68.533 s (ratio 2.889) |
| snowfall | C | — | — | — | 1 s (ratio 8.203) |
| aurora | C | — | — | — | 125.65 s (ratio 7.003) |
| fireflies | C | — | — | — | 102.067 s (ratio 5.969) |
| campfire | C | — | — | — | 170.25 s (ratio 2.931) |
| pond-ripples | C | — | — | — | 89.8 s (ratio 2.217) |
| falling-sand | C | — | — | — | 32.4 s (ratio 2.899) |
| smoke | C | — | — | — | 22 s (ratio 3.737) |
| typewriter | A | 23.15 s | 0.229 | 0 | 92.55 s (ratio 0.106) |

**Klasa A (6 scen):** synthwave 10 s, donut 125,667 s, tesseract 35,9 s, torus-knot 125,667 s, dna-helix 37,7 s, typewriter 23,15 s.
**Klasa C (15 scen):** doom-fire, matrix-rain, tunnel, tv-static, fireworks, reaction-diffusion, flow-field, rain, snowfall, aurora, fireflies, campfire, pond-ripples, falling-sand, smoke. Najlepsze dopasowanie ma ratio ≥ 0,95 (tunnel 1,14; doom-fire 1,86; pond-ripples 2,2; reszta większe), czyli szew byłby widoczny jako skok o jeden lub kilka zwykłych kroków. Dla nich pozostaje **długość klipu** bez pętli.

## Co z tego wynika
- Okresy donut i torus-knot (125,667 s) i dna-helix (3 × 12,57 s) wyglądają na wielokrotności π (40π ≈ 125,664; 4π ≈ 12,566). To obserwacja z liczb, nie z kodu: nie czytałem wzorów scen.
- Klatki po okresie niecałkowitym w klatkach mają błąd fazy do pół klatki (stąd ratio ≈ 0,1–0,2 zamiast 0). Dałoby się go zlikwidować, skalując prędkość o ułamek procenta tak, by T wypadało na całkowitej liczbie klatek (np. donut: 125,6637 s zamiast 125,6667 s, czyli ×0,99998). To pomysł `proj?`, nie zrobiony.
- Przy eksporcie o innym fps niż fps sceny T musi wypadać na całkowitej liczbie klatek wideo: np. 3,208 s (77 klatek przy 24 fps) daje 96,25 klatki przy 30 fps. Najprościej eksportować w fps sceny albo wybrać T z całkowitą liczbą klatek w obu.
- Sceny sekwencyjne (tesseract z listy `SEQUENTIAL_ONLY`) w odtwarzaczu na żywo (komponent) trzeba przy przekroczeniu T resetować do klatki 0, bo ich stan biegnie dalej. W pliku wideo problemu nie ma.

## Ograniczenia
1. Tylko opcje domyślne i 0–180 s. Inny tekst w typewriter/wave-text/scramble, inne `speed` czy `count` zmienią okresy.
2. Metryka znakowa, nie wizualna: nie oceniłem pętli okiem (nie renderowałem klipów).
3. **Tesseract:** rekomendowane 35,9 s ma szew 55% naturalnego kroku, więc jest graniczne. Lepsze dopasowanie (ratio 0,069) ma dopiero 161,6 s.
4. **Donut i torus-knot:** pętla 125,667 s to ok. 3770 klatek w 30 fps. Dłuższy plik; skrócenie wymaga akceptacji szwu (patrz best5 w JSON).
5. Zakres przeszukiwania kończy się na 180 s. Sceny klasy C mogłyby mieć pętle dłuższe.
6. Zgodność wyniku z ratio ≤ 0,25 to konwencja `proj`, nie wynik zewnętrznego kryterium percepcyjnego.
