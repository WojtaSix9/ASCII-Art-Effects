# Wyniki testów 30 scen startowych

Środowisko: Node 22.22 w piaskownicy; `env` nie przekazywane; opcje domyślne. Czasy orientacyjne.

## Co przeszło dla wszystkich 30
- Kształt klatki: dokładnie `rows` linii po `cols` znaków.
- **Determinizm:** dwie świeże instancje wywołane kolejno dają identyczne klatki (pierwsze 6 s).
- Wydajność: średnio poniżej 4 ms na klatkę (budżet oryginału). Najwolniejsze: reaction-diffusion 3,5 ms, mandelbrot 2,2 ms, campfire 1,9 ms; pozostałe poniżej 1 ms.

## Co NIE przechodzi bez odtwarzacza (7 scen)
doom-fire, reaction-diffusion, flow-field, snowfall, smoke, falling-sand, tesseract.

Przyczyna: scena pamięta ostatni czas i przesuwa stan o `t - last` (ucięte do małej wartości), więc
skok do dowolnej klatki daje inny obraz, a cofnięcie nic nie zmienia. W `falling-sand` powtórne
wywołanie tego samego `t` też zmienia wynik. W `tesseract` styl krawędzi zależy od poprzedniej klatki.

Rozwiązanie: `ScenePlayer` (src/player.ts) odtwarza takie sceny od klatki 0 i wywołuje każdą klatkę raz.
`scripts/check-player.ts`: skoki, cofanie i powtórzenia zgodne z przebiegiem sekwencyjnym dla wszystkich 30.

## Dokładne pętle (okno 2 s, do 180 s)
plasma 30 s · voronoi 30 s · cube 18 s · mandelbrot 48 s · wave-interference 90 s · big-text 16 s ·
glitch 7 s · wave-text 57 s · scramble 121,15 s.

**21 scen nie ma dokładnej pętli w 180 s** (m.in. donut, tunnel, rain, campfire, aurora, typewriter).
To nie znaczy, że nie da się zapętlić wizualnie. Test szuka identycznych klatek znak po znaku.
