# Wyniki testu renderera (30 scen startowych)

Środowisko: Node 22.22, @napi-rs/canvas, DejaVu Sans Mono, 1280x720 (czas: 1920x1080). Kazda scena przez `ScenePlayer`, w osobnym procesie.

## Przeszło dla 30 z 30
- Powtarzalność pikseli: dwie świeże pary (player + rasteryzator), ścieżka klatek 0, 7, 30, 12 (skok i cofnięcie).
- Skok/cofnięcie/powtórzenie daje te same piksele co przebieg kolejny (klatki 30, 12, 7, 0, 30 vs sekwencja 0..30).
- Kształt klatki (rows x cols) zgodny z meta. Wszystkie sceny mają `cell` 2.
- Czas renderu 1080p: najwolniej 7,7 ms/klatkę (orientacyjnie, piaskownica; bez kodowania wideo).

## Błąd znaleziony i naprawiony przez test
Glif szerszy od komórki przeciekał do sąsiedniej komórki paska atlasu, więc piksele zależały od kolejności glifów (synthwave, big-text). Naprawa: przycięcie każdego glifu do własnej komórki.

## Znaki
Z 60 s każdej sceny: 134 unikalne znaki, w tym ramki, bloki i cieniowanie (·─│┃┊┌┐└┘├┤┬┴┼═║╔╗╚╝╪╭╮╯╰╱╲▀▁..█▌▐░▒▓▔▖▗▙▚▛▜▞▟). Wszystkie mają glif w DejaVu Sans Mono. Brak znaków spoza BMP.
Uwaga: to tylko pierwsze 60 s i opcje domyślne; inne teksty w Big Text itp. mogą wnieść inne znaki.

## Szwy między blokami: naprawione
Przyczyna: font nie wypełnia całej komórki znakami `█` i pokrewnymi. Teraz `src/glyphs.ts` rysuje geometrią (prostokąty i linie na całkowitych krawędziach komórki): wszystkie 22 znaki Block Elements użyte przez sceny (▀▁–▇█▌▐▔░▒▓ i ćwiartki) oraz ramki ─│┃┊┌┐└┘├┤┬┴┼═║╔╗╚╝╪, łuki ╭╮╯╰ i przekątne ╱╲. Poza tym zbiorem znak wraca do fontu (np. `·` i cały ASCII).

`scripts/check-glyphs.ts` (`test`, 210 sprawdzeń, rozmiary komórki 4–49 px, `cell` 2 i 1, w tym nieparzyste): 210 z 210.
- siatka `█` bez szwów; ▀∪▄ = █, ▌∪▐ = █, ▘▝▖▗ = █, ▙∪▜ = ▛∪▟ = ▚∪▞ = █ (piksel w piksel),
- ▄ nad ▀ i ▐▌ tworzą jedną ciągłą wstęgę,
- pojedyncza, podwójna i zaokrąglona ramka oraz siatka ┬┴├┤┼ są spójne (jedna składowa; podwójna ma dwa pierścienie, jak powinna).
Pełny test 30 scen po zmianie: 30 z 30, czas renderu 1080p najwolniej 6,4 ms. Zrzuty: `reports/frames/` (big-text, synthwave, tv-static, falling-sand, glitch, donut, doom-fire, tesseract).

## Ograniczenia (nierozwiązane)
1. **Wygląd cieniowania.** ░▒▓ są teraz wzorem 4×8 kropek (25/50/75%), a nie wzorem z fontu. `▓` wychodzi jako jasne pole z ciemną kratką. To zmiana wyglądu względem fontu, nie błąd. Do oceny okiem.
2. **Małe komórki.** Przy wysokości komórki poniżej 16 px osiem poziomów ▁–█ nie jest rozróżnialnych (zaokrąglenia). W 1080p komórka ma ok. 48 px, więc nie dotyczy eksportu.
3. **Znaki poza zbiorem z 30 scen** (inne sceny P1/P2, inne teksty) wracają do fontu i mogą mieć te same szwy. Dodając scenę, uruchom `scan-chars.ts` i sprawdź nowe znaki Block Elements i Box Drawing.
4. **Łuki i przekątne** są antyaliasowane (linie prostych i bloków nie). Spójność łuków sprawdzona progiem alfa 16, nie 128.
5. **Piksele zgodne tylko w obrębie jednego środowiska** (rasteryzacja fontu i antyaliasing różnią się między przeglądarką a Node). Geometria bloków jest za to niezależna od fontu.
6. **Nie sprawdzone:** tryb z paletą (sceny kolorowe), `env.paper = true`, przebiegi dłuższe niż 60 s, inne opcje scen. Przy `paper`: `ScenePlayer` cache'uje ostatnią klatkę scen sekwencyjnych, więc zmiana `env` dla tego samego `k` nie odświeży wyniku.
7. Test sprawdza powtarzalność, zgodność i geometrię, a wygląd tylko na 8 zrzutach.
