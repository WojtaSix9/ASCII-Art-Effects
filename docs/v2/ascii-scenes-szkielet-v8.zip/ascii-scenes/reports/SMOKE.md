# Test dymny 30 scen (krok 5, `test`)

Każda scena w osobnym procesie, 2 s do MP4 (1920×1080, domyślne) i GIF (480×270, domyślne). `scripts/smoke-all.sh` → `reports/smoke.jsonl`.

**30/30 scen bez problemów.** Sprawdzane na scenę: MP4 (h264, yuv420p, 1920×1080, liczba klatek, fps), GIF (liczba klatek, suma opóźnień = round(klatki·100/fps), pętla nieskończona, 480×270), obraz nie jest pusty (≥2 kolory), dwa eksporty GIF identyczne bajtowo.

| scena | fps | klatek | MP4 KB | GIF KB | MP4 ms | GIF ms | różnych klatek | kolorów | RSS MB | opóźnienia cs |
|---|---|---|---|---|---|---|---|---|---|---|
| doom-fire | 24 | 48 | 577 | 133 | 3179 | 595 | 48 | 125 | 160 | 4/5 |
| matrix-rain | 20 | 40 | 765 | 126 | 2462 | 278 | 40 | 184 | 167 | 5 |
| plasma | 24 | 48 | 989 | 208 | 4259 | 346 | 48 | 111 | 163 | 4/5 |
| tunnel | 30 | 60 | 2030 | 215 | 5442 | 510 | 60 | 89 | 170 | 3/4 |
| tv-static | 20 | 40 | 749 | 125 | 2665 | 308 | 40 | 53 | 165 | 5 |
| synthwave | 20 | 40 | 151 | 19 | 2110 | 305 | 38 | 31 | 163 | 5 |
| fireworks | 30 | 60 | 115 | 34 | 1956 | 393 | 60 | 56 | 174 | 3/4 |
| mandelbrot | 15 | 30 | 610 | 85 | 2107 | 277 | 30 | 86 | 161 | 7/6 |
| voronoi | 15 | 30 | 171 | 39 | 1386 | 313 | 30 | 69 | 158 | 7/6 |
| reaction-diffusion | 20 | 40 | 647 | 61 | 2411 | 870 | 40 | 78 | 167 | 5 |
| flow-field | 20 | 40 | 134 | 31 | 1876 | 346 | 40 | 31 | 151 | 5 |
| donut | 30 | 60 | 529 | 124 | 3487 | 407 | 60 | 115 | 177 | 3/4 |
| cube | 24 | 48 | 81 | 21 | 2089 | 293 | 16 | 67 | 171 | 4/5 |
| tesseract | 30 | 60 | 143 | 42 | 2429 | 318 | 60 | 48 | 148 | 3/4 |
| torus-knot | 30 | 60 | 763 | 97 | 3231 | 541 | 60 | 69 | 180 | 3/4 |
| dna-helix | 20 | 40 | 125 | 31 | 1622 | 313 | 40 | 41 | 167 | 5 |
| rain | 30 | 60 | 276 | 77 | 2823 | 313 | 60 | 95 | 176 | 3/4 |
| snowfall | 20 | 40 | 74 | 29 | 1699 | 373 | 40 | 31 | 157 | 5 |
| aurora | 20 | 40 | 157 | 34 | 1829 | 342 | 40 | 48 | 166 | 5 |
| fireflies | 15 | 30 | 93 | 20 | 1436 | 304 | 30 | 80 | 163 | 7/6 |
| campfire | 20 | 40 | 244 | 50 | 1962 | 641 | 40 | 126 | 163 | 5 |
| wave-interference | 24 | 48 | 539 | 151 | 3038 | 333 | 48 | 65 | 171 | 4/5 |
| pond-ripples | 20 | 40 | 83 | 21 | 1583 | 232 | 40 | 73 | 166 | 5 |
| falling-sand | 20 | 40 | 49 | 21 | 1953 | 307 | 40 | 56 | 168 | 5 |
| smoke | 30 | 60 | 72 | 24 | 2004 | 358 | 60 | 74 | 183 | 3/4 |
| big-text | 24 | 48 | 105 | 9 | 1794 | 225 | 36 | 2 | 170 | 4/5 |
| typewriter | 20 | 40 | 17 | 5 | 1231 | 222 | 16 | 145 | 165 | 5 |
| glitch | 15 | 30 | 69 | 19 | 1316 | 207 | 8 | 2 | 160 | 7/6 |
| wave-text | 15 | 30 | 30 | 9 | 925 | 251 | 17 | 180 | 167 | 7/6 |
| scramble | 20 | 40 | 88 | 25 | 1455 | 248 | 26 | 196 | 182 | 5 |

Maksima: MP4 2030 KB, GIF 215 KB, RSS Node 183 MB, czas GIF 870 ms, czas MP4 5442 ms (wartości orientacyjne, piaskownica).

Sceny, w których 2 s zawierają mało różnych klatek (to cecha sceny, nie błąd eksportu): cube 16/48, typewriter 16/40, glitch 8/30, wave-text 17/30, big-text 36/48, scramble 26/40.

**Nie testowano:** odtwarzania GIF w przeglądarkach i komunikatorach, klipów dłuższych niż 2 s w tym teście (długi klip osobno: `scripts/long-gif.ts`), `env.paper`, opcji ink/background w teście dymnym (są w `check-gif.ts`).
