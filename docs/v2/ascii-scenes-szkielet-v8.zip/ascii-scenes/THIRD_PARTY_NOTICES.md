# Third-party notices

## ascii.rest (bas3line/ascii)

- Source: https://github.com/bas3line/ascii (site: https://ascii.rest)
- Licence: MIT, `Copyright (c) 2026 bas3line` (full text: `LICENSES/ascii.rest-MIT.txt`)
- Version: package 0.2.1, commit `2572c26` (2026-10-08), retrieved 2026-10-09

Files copied **without changes**:

- `src/types.ts`
- `src/pieces/*.ts` (30 files): aurora, big-text, campfire, cube, dna-helix, donut, doom-fire, falling-sand, fireflies, fireworks, flow-field, glitch, mandelbrot, matrix-rain, plasma, pond-ripples, rain, reaction-diffusion, scramble, smoke, snowfall, synthwave, tesseract, torus-knot, tunnel, tv-static, typewriter, voronoi, wave-interference, wave-text

Notes carried over from the file headers of the copied pieces:

- `donut.ts`: "After Andy Sloane's donut.c" (an algorithm the author re-implements).
- `reaction-diffusion.ts`: a Gray-Scott reaction (a published model).

Not copied: logo, company and distro pieces (trademarks of their owners), `terminal.ts`, `cli.ts`, `site/`, `scripts/`.

## Our own additions (not from ascii.rest)

`src/registry.ts`, `src/player.ts`, `scripts/*.ts`, `reports/*`, `README.md`.
