# ascii-scenes (szkielet modułu animowanych scen ASCII)

Krok 1 planu z pliku 03: 30 scen startowych z ascii.rest (MIT), kontrakt `types.ts`, rejestr,
odtwarzacz `ScenePlayer` i testy powtarzalności.

## Struktura
- `LICENSES/ascii.rest-MIT.txt`, `THIRD_PARTY_NOTICES.md`: licencja i lista przejętych plików (wymóg MIT)
- `src/types.ts`, `src/pieces/*.ts`: przejęte bez zmian
- `src/registry.ts`: rejestr 30 scen
- `src/player.ts`: **nasz** odtwarzacz; sceny wymagające odtwarzania od klatki 0 (lista `SEQUENTIAL_ONLY`) odtwarza od zera przy skoku lub cofnięciu
- `scripts/check.ts`: kształt klatki, determinizm, idempotencja, dostęp losowy, wydajność
- `scripts/check-player.ts`: sprawdza, że `ScenePlayer` zgadza się z odtwarzaniem sekwencyjnym
- `scripts/find-loops.ts`: szuka dokładnego okresu pętli (okno 2 s, do 180 s)
- `src/render.ts`: **nasz** renderer offline (tryb tekstowy): `createRasterizer(makeCanvas).renderFrame(player, piece.meta, k, {width, height, ink, background, font, paper})`
- `src/glyphs.ts`: **nasz** rysunek bloków i ramek geometrią (bez szwów); `scripts/check-glyphs.ts`: jego testy
- `scripts/check-render.ts`, `check-render-all.sh`: test renderera na 30 scenach (każda w osobnym procesie, bo natywne kanwy zjadają pamięć); `scripts/scan-chars.ts`: znaki używane przez sceny
- `reports/`: wyniki (`WYNIKI.md`, `check.json`, `loops.json`)

## Uruchomienie
Testowane na Node 22.22 (Node uruchamia pliki `.ts` bezpośrednio, importy mają rozszerzenie `.ts`).

```
node scripts/check.ts
node scripts/check-player.ts
node scripts/find-loops.ts
```

## Zasada użycia
Scenę zawsze odtwarzaj przez `ScenePlayer`: `new ScenePlayer(piece, id).at(k)` daje klatkę numer `k` (czas `k / fps`),
a `atTime(sekundy)` klatkę dla czasu z osi eksportu.

## Renderer (krok 2)
Wymaga implementacji canvasa 2D (przeglądarka: `OffscreenCanvas`; Node: `@napi-rs/canvas`, `npm i`).
Komórka ma całkowity rozmiar w px (`ch = cw * cell`), siatka jest wyśrodkowana. Glify są przycinane do własnej komórki.
Znane ograniczenia: patrz `reports/WYNIKI-RENDER.md`.

## Pętle z tolerancją (krok 2b)
`scripts/find-loops-tol.ts <id> [maxSeconds] [okno s]`, `find-loops-tol-all.sh` (wszystkie sceny po kolei, każda w osobnym procesie). Wyniki i opis metody: `reports/LOOPS.md`, dane: `reports/loops-tol.json`.

## Eksport (krok 4.1)
`src/export-node.ts`: `exportPng(scena, k, opcje)`, `exportText(scena, k)`. CLI: `node scripts/export.ts <scena> <png|txt> [--k N] [--out plik] [--ink #hex] [--bg #hex|transparent] [--size WxH | --cell N]`.
Renderer ma dwie ścieżki: kanwa (`renderFrameInto`, dla PNG) i bufor RGBA (`renderFrameToBuffer`, dla wideo; odczyt pikseli z kanwy przecieka pamięć). Testy: `node --expose-gc scripts/check-export.ts`, `check-buffer.ts`. Spec: `04-eksport.md`.

## Długość klipu i MP4 (kroki 4.2 i 4.3)
`scripts/gen-durations.ts` generuje `src/durations.ts` z `reports/loops-tol.json`; `src/clip.ts` (`resolveClip`) wybiera liczbę klatek. `src/export-video.ts`: `exportMp4(scena, plik, opcje)` (wymaga ffmpeg w PATH, `FFMPEG_PATH` lub opcji `ffmpeg`). CLI: `node scripts/export.ts cube mp4 --out out/cube.mp4 [--seconds N | --repeat N] [--loop exact] [--fps N]`.
Testy: `node --expose-gc scripts/check-mp4.ts`, `node scripts/long-mp4.ts donut` (3770 klatek 1080p, ok. 3 min).
