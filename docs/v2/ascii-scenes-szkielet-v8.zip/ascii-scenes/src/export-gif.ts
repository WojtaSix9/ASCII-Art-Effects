// GIF export through ffmpeg (krok 4.4). Own code (proj).
// Two passes over the same deterministic frames (palette first, then encoding), so memory stays flat for any length:
//   pass 1: frames -> ffmpeg palettegen -> one global 256-colour palette (PNG)
//   pass 2: frames + palette -> ffmpeg paletteuse (no dithering: the scene is flat ink on flat background) -> GIF
// Frame delays are then rewritten by setGifDelays (exact integer centiseconds, no loop-length drift).
import { spawn } from 'node:child_process';
import { mkdirSync, mkdtempSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { ScenePlayer } from './player.ts';
import { resolveClip } from './clip.ts';
import type { Clip, ClipRequest } from './clip.ts';
import { ensureFont, getScene, rasterizer, renderOptions } from './export-node.ts';
import type { FrameOptions } from './export-node.ts';
import { exactDelays, setGifDelays } from './gif-parse.ts';

export const GIF_DEFAULT_SIZE = { width: 480, height: 270 };
export const GIF_MAX_SECONDS = 10;           // decyzja uzytkownika: GIF ma najwyzej 10 s (twardy limit)

export type GifOptions = FrameOptions & ClipRequest & {
  maxColors?: number;                        // default 256
  ffmpeg?: string;
  onProgress?: (done: number, total: number) => void;
};
export type GifResult = { path: string; clip: Clip; width: number; height: number; delaysCs: number[]; warnings: string[] };

const bin = (o: GifOptions) => o.ffmpeg ?? process.env.FFMPEG_PATH ?? 'ffmpeg';

type Pass = { args: string[]; ro: ReturnType<typeof renderOptions>; id: string; clip: Clip; o: GifOptions; progress?: boolean };

async function runPass(p: Pass): Promise<void> {
  const { piece, meta } = getScene(p.id);
  const ff = spawn(bin(p.o), p.args, { stdio: ['pipe', 'ignore', 'pipe'] });
  let err = '';
  ff.stderr.on('data', (d: Buffer) => { err = (err + d.toString()).slice(-4000); });
  const exited = new Promise<number>((res, rej) => { ff.on('error', rej); ff.on('close', (c) => res(c ?? -1)); });
  exited.catch(() => {});
  ff.stdin.on('error', () => {});
  const player = new ScenePlayer(piece, p.id);       // fresh player per pass: frames must be requested in ascending order
  const buf = Buffer.alloc(p.ro.width * p.ro.height * 4);
  let failed: unknown = null;
  try {
    for (let n = 0; n < p.clip.frames; n++) {
      const k = Math.round(n * p.clip.sceneFps / p.clip.videoFps);
      rasterizer.renderFrameToBuffer(buf, player, meta, k, p.ro);
      await new Promise<void>((res, rej) => ff.stdin.write(buf, (e) => (e ? rej(e) : res())));
      if (p.progress && p.o.onProgress && (n % 50 === 49 || n === p.clip.frames - 1)) p.o.onProgress(n + 1, p.clip.frames);
    }
  } catch (e) { failed = e; }
  ff.stdin.end();
  let code: number;
  try { code = await exited; } catch (e) { throw new Error(`cannot start ffmpeg ("${bin(p.o)}"): ${(e as Error).message}. Install ffmpeg or set FFMPEG_PATH.`); }
  if (code !== 0 || failed) throw new Error(`ffmpeg failed (exit ${code})${failed ? `, write error: ${(failed as Error).message}` : ''}: ${err.trim()}`);
}

export async function exportGif(id: string, outPath: string, o: GifOptions = {}): Promise<GifResult> {
  ensureFont();
  const { meta } = getScene(id);
  if (o.background === null) throw new Error('transparent background is not supported in GIF (v1); use PNG');
  let clip = resolveClip(id, o);
  const warnings: string[] = [];
  if (clip.seconds > GIF_MAX_SECONDS + 1e-9) {
    if (o.seconds !== undefined || o.repeat !== undefined) throw new Error(`GIF is limited to ${GIF_MAX_SECONDS} s, requested ${clip.seconds.toFixed(2)} s (use MP4 for longer clips)`);
    const full = clip.seconds;
    clip = resolveClip(id, { ...o, seconds: GIF_MAX_SECONDS });
    warnings.push(`default clip of ${full.toFixed(1)} s exceeds the GIF limit: cut to ${GIF_MAX_SECONDS} s`);
  }
  warnings.push(...clip.warnings);
  if (clip.videoFps > 50) warnings.push(`${clip.videoFps} fps: GIF delays under 2 cs are slowed down by many browsers`);
  const ro = renderOptions(meta, { ...o, size: o.size ?? GIF_DEFAULT_SIZE });
  const maxColors = o.maxColors ?? 256;
  if (!(Number.isInteger(maxColors) && maxColors >= 2 && maxColors <= 256)) throw new Error('maxColors must be an integer 2..256');
  mkdirSync(dirname(outPath), { recursive: true });
  const tmp = mkdtempSync(join(tmpdir(), 'gif-'));
  const palette = join(tmp, 'palette.png'), part = outPath + '.part';
  const input = ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', `${ro.width}x${ro.height}`, '-framerate', String(clip.videoFps), '-i', 'pipe:0'];
  try {
    await runPass({ id, clip, o, ro, args: [...input, '-vf', `palettegen=max_colors=${maxColors}:stats_mode=full:reserve_transparent=0`, '-frames:v', '1', '-update', '1', palette] });
    await runPass({ id, clip, o, ro, progress: true, args: [...input, '-i', palette,
      '-lavfi', '[0:v][1:v]paletteuse=dither=none:diff_mode=none', '-loop', '0', '-fflags', '+bitexact', '-f', 'gif', part] });
    const delaysCs = exactDelays(clip.frames, clip.videoFps);
    writeFileSync(part, setGifDelays(readFileSync(part), delaysCs));
    renameSync(part, outPath);
    return { path: outPath, clip, width: ro.width, height: ro.height, delaysCs, warnings };
  } catch (e) {
    rmSync(part, { force: true });
    throw e;
  } finally { rmSync(tmp, { recursive: true, force: true }); }
}
