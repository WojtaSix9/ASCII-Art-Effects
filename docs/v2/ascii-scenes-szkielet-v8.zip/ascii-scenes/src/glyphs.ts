// Geometric drawing of Block Elements (U+2580-259F) and the box-drawing characters used by the scenes.
// Fonts do not fill the whole cell with these, which leaves seams between neighbouring cells; drawing them
// as rectangles and lines on integer cell edges makes neighbours join exactly. Own code (proj).
// Used characters come from reports/chars.json (first 60 s of the 30 starter scenes). Anything not handled
// here returns false and falls back to the font.

type G = any; // 2D context

const r = Math.round;

// Light quadruple vertical dash (┊) is handled separately. Arms: l, r, u, d = 0 none, 1 light, 2 heavy.
const ARMS: Record<string, [number, number, number, number]> = {
  '─': [1, 1, 0, 0], '│': [0, 0, 1, 1], '┃': [0, 0, 2, 2],
  '┌': [0, 1, 0, 1], '┐': [1, 0, 0, 1], '└': [0, 1, 1, 0], '┘': [1, 0, 1, 0],
  '├': [0, 1, 1, 1], '┤': [1, 0, 1, 1], '┬': [1, 1, 0, 1], '┴': [1, 1, 1, 0], '┼': [1, 1, 1, 1],
};

// Quadrants: bits UL, UR, LL, LR
const QUAD: Record<string, number> = {
  '▖': 0b0010, '▗': 0b0001, '▘': 0b1000, '▝': 0b0100,
  '▙': 0b1011, '▚': 0b1001, '▛': 0b1110, '▜': 0b1101, '▞': 0b0110, '▟': 0b0111,
};

function rect(g: G, x0: number, y0: number, x1: number, y1: number) {
  if (x1 > x0 && y1 > y0) g.fillRect(x0, y0, x1 - x0, y1 - y0);
}

/** Draws char c into the cell (x, y, w, h) with the current fillStyle. Returns false if c is not handled. */
export function drawGeometric(g: G, c: string, x: number, y: number, w: number, h: number): boolean {
  const cp = c.codePointAt(0)!;
  const xm = (f: number) => x + r(w * f), ym = (f: number) => y + r(h * f);

  // --- Block Elements ---
  if (cp === 0x2588) { rect(g, x, y, x + w, y + h); return true; }                  // █
  if (cp === 0x2580) { rect(g, x, y, x + w, ym(1 / 2)); return true; }               // ▀
  if (cp >= 0x2581 && cp <= 0x2587) { const n = cp - 0x2580; rect(g, x, y + h - r(h * n / 8), x + w, y + h); return true; } // ▁..▇
  if (cp === 0x258C) { rect(g, x, y, xm(1 / 2), y + h); return true; }               // ▌
  if (cp === 0x2590) { rect(g, xm(1 / 2), y, x + w, y + h); return true; }           // ▐
  if (cp === 0x2594) { rect(g, x, y, x + w, y + Math.max(1, r(h / 8))); return true; } // ▔
  if (cp === 0x2595) { rect(g, x + w - Math.max(1, r(w / 8)), y, x + w, y + h); return true; } // ▕
  if (c in QUAD) {
    const q = QUAD[c], xc = xm(1 / 2), yc = ym(1 / 2);
    if (q & 8) rect(g, x, y, xc, yc);
    if (q & 4) rect(g, xc, y, x + w, yc);
    if (q & 2) rect(g, x, yc, xc, y + h);
    if (q & 1) rect(g, xc, yc, x + w, y + h);
    return true;
  }
  if (cp >= 0x2591 && cp <= 0x2593) { // ░ ▒ ▓: dither on a 4 x 8 grid of dots whose edges snap to the cell edges
    const kind = cp - 0x2590; // 1 light, 2 medium, 3 dark
    for (let j = 0; j < 8; j++) for (let i = 0; i < 4; i++) {
      const on = kind === 2 ? (i + j) % 2 === 0 : kind === 1 ? (i % 2 === 0 && j % 2 === 0) : !(i % 2 === 1 && j % 2 === 1);
      if (on) rect(g, x + r(w * i / 4), y + r(h * j / 8), x + r(w * (i + 1) / 4), y + r(h * (j + 1) / 8));
    }
    return true;
  }

  // --- Box drawing ---
  const t = Math.max(1, r(w / 8)), T = t * 2;          // light and heavy thickness
  const cx = x + w / 2, cy = y + h / 2;
  const span = (centre: number, th: number) => [r(centre - th / 2), r(centre - th / 2) + th] as const; // keeps th px exactly
  if (c in ARMS) {
    const [l, rr, u, d] = ARMS[c];
    const th = (a: number) => (a === 2 ? T : t);
    const wide = Math.max(l ? th(l) : 0, rr ? th(rr) : 0, u ? th(u) : 0, d ? th(d) : 0);
    const [vx0, vx1] = span(cx, wide), [hy0, hy1] = span(cy, wide);
    // vertical arms use the vertical thickness, horizontal arms the horizontal one; corners overlap at the centre
    if (l) { const [a, b] = span(cy, th(l)); rect(g, x, a, vx1, b); }
    if (rr) { const [a, b] = span(cy, th(rr)); rect(g, vx0, a, x + w, b); }
    if (u) { const [a, b] = span(cx, th(u)); rect(g, a, y, b, hy1); }
    if (d) { const [a, b] = span(cx, th(d)); rect(g, a, hy0, b, y + h); }
    return true;
  }
  if (cp === 0x250A) { // ┊ light quadruple dash vertical
    const [a, b] = span(cx, t);
    for (let i = 0; i < 4; i++) rect(g, a, y + r(h * (2 * i + 0.5) / 8), b, y + r(h * (2 * i + 1.5) / 8));
    return true;
  }
  // double lines: two strokes of thickness t at +-t from the centre
  const dd = t;
  if ('═║╔╗╚╝╪'.includes(c)) {
    const [ay0, ay1] = span(cy - dd, t), [by0, by1] = span(cy + dd, t);
    const [ax0, ax1] = span(cx - dd, t), [bx0, bx1] = span(cx + dd, t);
    switch (c) {
      case '═': case '╪': rect(g, x, ay0, x + w, ay1); rect(g, x, by0, x + w, by1);
        if (c === '╪') { const [a, b] = span(cx, t); rect(g, a, y, b, ay0); rect(g, a, ay1, b, by0); rect(g, a, by1, b, y + h); } break;
      case '║': rect(g, ax0, y, ax1, y + h); rect(g, bx0, y, bx1, y + h); break;
      case '╔': rect(g, ax0, ay0, x + w, ay1); rect(g, bx0, by0, x + w, by1); rect(g, ax0, ay0, ax1, y + h); rect(g, bx0, by0, bx1, y + h); break;
      case '╗': rect(g, x, ay0, bx1, ay1); rect(g, x, by0, ax1, by1); rect(g, bx0, ay0, bx1, y + h); rect(g, ax0, by0, ax1, y + h); break;
      case '╚': rect(g, ax0, y + 0, ax1, by1); rect(g, bx0, y, bx1, ay1); rect(g, ax0, by0, x + w, by1); rect(g, bx0, ay0, x + w, ay1); break;
      case '╝': rect(g, bx0, y, bx1, by1); rect(g, ax0, y, ax1, ay1); rect(g, x, by0, bx1, by1); rect(g, x, ay0, ax1, ay1); break;
    }
    return true;
  }
  if ('╭╮╯╰'.includes(c)) { // rounded corners: a quarter curve between the two edge midpoints
    g.save(); g.lineWidth = t; g.lineCap = 'butt'; g.strokeStyle = g.fillStyle;
    g.beginPath();
    // snap the stroke centre to the centre of the pixel-aligned straight arms, so curves join them exactly
    const mx = r(cx - t / 2) + t / 2, my = r(cy - t / 2) + t / 2;
    if (c === '╭') { g.moveTo(x + w, my); g.quadraticCurveTo(mx, my, mx, y + h); }
    if (c === '╮') { g.moveTo(x, my); g.quadraticCurveTo(mx, my, mx, y + h); }
    if (c === '╯') { g.moveTo(x, my); g.quadraticCurveTo(mx, my, mx, y); }
    if (c === '╰') { g.moveTo(x + w, my); g.quadraticCurveTo(mx, my, mx, y); }
    g.stroke(); g.restore();
    return true;
  }
  if (c === '╱' || c === '╲') { // diagonals, corner to corner (callers clip to the cell)
    g.save(); g.lineWidth = t; g.strokeStyle = g.fillStyle; g.beginPath();
    if (c === '╱') { g.moveTo(x, y + h); g.lineTo(x + w, y); } else { g.moveTo(x, y); g.lineTo(x + w, y + h); }
    g.stroke(); g.restore();
    return true;
  }
  return false;
}
