// Odtwarzacz sceny z gwarancja powtarzalnosci.
//
// Czesc scen to symulacje, ktore pamietaja ostatni czas i przesuwaja stan o (t - last).
// Takie sceny dzialaja poprawnie tylko przy wywolaniach kolejno, co 1/fps, od klatki 0.
// Odtwarzacz robi to za nas: przy skoku lub cofnieciu tworzy swieza instancje i odtwarza
// klatki od zera, a kazda klatke wywoluje dokladnie raz (wynik jest cache'owany).
//
// Lista SEQUENTIAL_ONLY pochodzi z testu `npm run check` (rozbieznosc: skok vs przebieg).
import type { Piece, Frame, Env } from "./types.ts";

export const SEQUENTIAL_ONLY = new Set([
  "doom-fire", "reaction-diffusion", "flow-field", "snowfall",
  "smoke", "falling-sand", "tesseract",
]);

export class ScenePlayer {
  readonly fps: number;
  private piece: Piece<any>;
  private options?: Record<string, unknown>;
  private frame!: Frame;
  private idx = -1;            // numer ostatnio policzonej klatki
  private last = "";           // jej tekst
  private readonly sequential: boolean;

  constructor(piece: Piece<any>, id: string, options?: Record<string, unknown>) {
    this.piece = piece;
    this.options = options;
    this.fps = piece.meta.fps;
    this.sequential = SEQUENTIAL_ONLY.has(id) && this.fps > 0;
    this.reset();
  }

  private reset() { this.frame = this.piece.default(this.options); this.idx = -1; this.last = ""; }

  /** Klatka o numerze k (czas k / fps). Dla scen nieruchomych (fps 0) zawsze klatka 0. */
  at(k: number, env?: Env): string {
    if (!this.fps) return (this.last ||= this.frame(0, env));
    k = Math.max(0, Math.round(k));
    if (!this.sequential) return this.frame(k / this.fps, env);   // bezstanowa: wprost
    if (k === this.idx) return this.last;                           // juz policzona
    if (k < this.idx) this.reset();                                 // cofniecie: od zera
    for (let i = this.idx + 1; i <= k; i++) this.last = this.frame(i / this.fps, env);
    this.idx = k;
    return this.last;
  }

  /** Klatka dla dowolnego czasu w sekundach (np. z osi czasu eksportu). */
  atTime(seconds: number, env?: Env): string {
    return this.at(Math.floor(seconds * this.fps + 1e-6), env);
  }
}
