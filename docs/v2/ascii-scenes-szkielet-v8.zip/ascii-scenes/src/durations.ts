// GENEROWANE przez scripts/gen-durations.ts z reports/loops-tol.json. Nie edytowac recznie.
// loopFrames/loopSeconds: rekomendowana petla (ratio <= 0.25, zob. reports/LOOPS.md), null = brak petli.
// exactSeconds: dokladna petla (test rownosci okna 2 s w 180 s), null = brak.
// cls: A = jest rekomendowana petla, A? = tylko graniczna, B = szum, C = brak petli.
export type DurationInfo = { fps: number; loopFrames: number | null; loopSeconds: number | null; exactSeconds: number | null; cls: string };
export const DURATIONS: Record<string, DurationInfo> = {
  "doom-fire": { fps: 24, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "matrix-rain": { fps: 20, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "plasma": { fps: 24, loopFrames: 720, loopSeconds: 30, exactSeconds: 30, cls: "A" },
  "tunnel": { fps: 30, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "tv-static": { fps: 20, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "synthwave": { fps: 20, loopFrames: 200, loopSeconds: 10, exactSeconds: null, cls: "A" },
  "fireworks": { fps: 30, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "mandelbrot": { fps: 15, loopFrames: 720, loopSeconds: 48, exactSeconds: 48, cls: "A" },
  "voronoi": { fps: 15, loopFrames: 450, loopSeconds: 30, exactSeconds: 30, cls: "A" },
  "reaction-diffusion": { fps: 20, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "flow-field": { fps: 20, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "donut": { fps: 30, loopFrames: 3770, loopSeconds: 125.667, exactSeconds: null, cls: "A" },
  "cube": { fps: 24, loopFrames: 144, loopSeconds: 6, exactSeconds: 18, cls: "A" },
  "tesseract": { fps: 30, loopFrames: 1077, loopSeconds: 35.9, exactSeconds: null, cls: "A" },
  "torus-knot": { fps: 30, loopFrames: 3770, loopSeconds: 125.667, exactSeconds: null, cls: "A" },
  "dna-helix": { fps: 20, loopFrames: 754, loopSeconds: 37.7, exactSeconds: null, cls: "A" },
  "rain": { fps: 30, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "snowfall": { fps: 20, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "aurora": { fps: 20, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "fireflies": { fps: 15, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "campfire": { fps: 20, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "wave-interference": { fps: 24, loopFrames: 2160, loopSeconds: 90, exactSeconds: 90, cls: "A" },
  "pond-ripples": { fps: 20, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "falling-sand": { fps: 20, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "smoke": { fps: 30, loopFrames: null, loopSeconds: null, exactSeconds: null, cls: "C" },
  "big-text": { fps: 24, loopFrames: 77, loopSeconds: 3.208, exactSeconds: 16, cls: "A" },
  "typewriter": { fps: 20, loopFrames: 463, loopSeconds: 23.15, exactSeconds: null, cls: "A" },
  "glitch": { fps: 15, loopFrames: 105, loopSeconds: 7, exactSeconds: 7, cls: "A" },
  "wave-text": { fps: 15, loopFrames: 107, loopSeconds: 7.133, exactSeconds: 57, cls: "A" },
  "scramble": { fps: 20, loopFrames: 269, loopSeconds: 13.45, exactSeconds: 121.15, cls: "A" },
};
