// MP4 export through ffmpeg (krok 4.3). Own code (proj).
// Frames are composed by the canvas-free buffer path (render.ts renderFrameToBuffer) and piped to ffmpeg as raw RGBA.
import { spawn } from 'node:child_process';
import { mkdirSync, renameSync, rmSync } from 'node:fs';
import { dirname } from 'node:path';
import { ScenePlayer } from './player.ts';
import { resolveClip } from './clip.ts';
import type { Clip, ClipRequest } from './clip.ts';
import { ensureFont, getScene, rasterizer, renderOptions } from './export-node.ts';
import type { FrameOptions } from './export-node.ts';

export type VideoOptions = FrameOptions & ClipRequest & {
  crf?: number;                         // x264 quality, default 18 (lower = better and bigger)
  preset?: string;                      // x264 preset, default 'medium'
  ffmpeg?: string;                      // path to ffmpeg; else env FFMPEG_PATH; else 'ffmpeg' from PATH
  onProgress?: (done: number, total: number) => void;
};
export type VideoResult = { path: string; clip: Clip; width: number; height: number; bytesPerFrame: number };

function ffmpegBinary(o: VideoOptions): string { return o.ffmpeg ?? process.env.FFMPEG_PATH ?? 'ffmpeg'; }

export async function exportMp4(id: string, outPath: string, o: VideoOptions = {}): Promise<VideoResult> {
  ensureFont();
  const { piece, meta } = getScene(id);
  if (o.background === null) throw new Error('MP4 cannot have a transparent background (use PNG)');
  const clip = resolveClip(id, o);
  const ro = renderOptions(meta, o);
  if (ro.width % 2 || ro.height % 2) throw new Error(`MP4 (yuv420p) needs even dimensions, got ${ro.width}x${ro.height}`);
  const crf = o.crf ?? 18, preset = o.preset ?? 'medium';
  mkdirSync(dirname(outPath), { recursive: true });
  const part = outPath + '.part';
  // RGB -> YUV with the BT.709 matrix and limited range, tagged accordingly, so players show the same colours we drew.
  const args = [
    '-hide_banner', '-loglevel', 'error', '-y',
    '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', `${ro.width}x${ro.height}`, '-framerate', String(clip.videoFps), '-i', 'pipe:0',
    '-an', '-vf', 'scale=out_color_matrix=bt709:out_range=tv,format=yuv420p',
    '-c:v', 'libx264', '-preset', preset, '-crf', String(crf),
    '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-color_range', 'tv',
    '-movflags', '+faststart', '-fflags', '+bitexact', '-flags:v', '+bitexact', '-f', 'mp4', part,
  ];
  const ff = spawn(ffmpegBinary(o), args, { stdio: ['pipe', 'ignore', 'pipe'] });
  let errText = '';
  ff.stderr.on('data', (d: Buffer) => { errText = (errText + d.toString()).slice(-4000); });
  const exited = new Promise<number>((res, rej) => { ff.on('error', rej); ff.on('close', (c) => res(c ?? -1)); });
  exited.catch(() => {});          // spawn failure is reported below; avoid an unhandled rejection meanwhile
  ff.stdin.on('error', () => {});  // EPIPE if ffmpeg dies: surfaced through the write callback and the exit code
  const player = new ScenePlayer(piece, id);
  const buf = Buffer.alloc(ro.width * ro.height * 4);
  let failed: unknown = null;
  try {
    for (let n = 0; n < clip.frames; n++) {
      const k = Math.round(n * clip.sceneFps / clip.videoFps);      // non-decreasing: ScenePlayer needs sequential order
      rasterizer.renderFrameToBuffer(buf, player, meta, k, ro);
      // wait until the chunk is handled before the buffer is reused: write() keeps a reference, it does not copy
      await new Promise<void>((res, rej) => ff.stdin.write(buf, (err) => (err ? rej(err) : res())));
      if (o.onProgress && (n % 50 === 49 || n === clip.frames - 1)) o.onProgress(n + 1, clip.frames);
    }
  } catch (e) { failed = e; }
  ff.stdin.end();
  let code: number;
  try { code = await exited; } catch (e) { rmSync(part, { force: true }); throw new Error(`cannot start ffmpeg ("${ffmpegBinary(o)}"): ${(e as Error).message}. Install ffmpeg or set FFMPEG_PATH.`); }
  if (code !== 0 || failed) {
    rmSync(part, { force: true });
    throw new Error(`ffmpeg failed (exit ${code})${failed ? `, write error: ${(failed as Error).message}` : ''}: ${errText.trim()}`);
  }
  renameSync(part, outPath);
  return { path: outPath, clip, width: ro.width, height: ro.height, bytesPerFrame: buf.length };
}
