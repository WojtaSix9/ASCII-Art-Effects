// GIF encoder without Node dependencies (proj): runs in the browser as well as in Node. Uses gifenc (MIT) for LZW only.
// Input: a function that renders frame n as RGBA (Uint8Array|Uint8ClampedArray, w*h*4); it is called TWICE per frame
// (pass 1 builds the palette, pass 2 encodes), so memory stays flat and the output is deterministic.
// Palette: if the clip has <= maxColors-1 distinct colours (always true for ink-on-background scenes so far: 67-196),
// the palette is EXACT, i.e. the GIF is lossless; otherwise gifenc's quantizer is used on a sample of frames.
// Inter-frame transparency (like ffmpeg's `transdiff`): unchanged pixels become the reserved transparent index.
import * as gifenc from 'gifenc';
import { exactDelays } from './gif-parse.ts';

// Node resolves gifenc to its CommonJS build (named exports arrive under .default); bundlers use the ESM build (named exports).
const lib: any = (gifenc as any).GIFEncoder ? gifenc : (gifenc as any).default;
const { GIFEncoder, quantize, applyPalette } = lib as { GIFEncoder: () => any; quantize: (...a: any[]) => number[][]; applyPalette: (...a: any[]) => Uint8Array };

export type GifJsOptions = {
  width: number; height: number; frames: number; fps: number;
  frame: (n: number) => Uint8Array | Uint8ClampedArray;
  maxColors?: number;                       // 2..256, default 256 (one index is reserved for transparency when frames > 1)
  interFrameTransparency?: boolean;         // default true
  onProgress?: (done: number, total: number) => void;
};
export type GifJsResult = { bytes: Uint8Array; delaysCs: number[]; paletteSize: number; exact: boolean };

export function encodeGif(o: GifJsOptions): GifJsResult {
  const { width: w, height: h, frames, fps } = o;
  const maxColors = o.maxColors ?? 256;
  if (!(Number.isInteger(w) && w > 0 && Number.isInteger(h) && h > 0 && Number.isInteger(frames) && frames > 0 && fps > 0)) throw new Error('invalid size, frames or fps');
  if (!(Number.isInteger(maxColors) && maxColors >= 2 && maxColors <= 256)) throw new Error('maxColors must be an integer 2..256');
  const useTrans = (o.interFrameTransparency ?? true) && frames > 1;
  const limit = maxColors - (useTrans ? 1 : 0);                 // colours available for the image itself
  if (limit < 1) throw new Error('maxColors too small for inter-frame transparency');

  // pass 1: exact palette if it fits, else sample for the quantizer
  const seen = new Map<number, number>(); let overflow = false;
  const sample: Uint8Array[] = []; const step = Math.max(1, Math.ceil(frames / 8));
  for (let n = 0; n < frames; n++) {
    const f = o.frame(n);
    if (!overflow) for (let i = 0; i < f.length; i += 4) { const k = f[i] << 16 | f[i + 1] << 8 | f[i + 2]; if (!seen.has(k)) { if (seen.size >= limit) { overflow = true; break; } seen.set(k, seen.size); } }
    if (n % step === 0 || n === frames - 1) sample.push(Uint8Array.from(f));
  }
  let palette: number[][]; let exact = !overflow; let map: Map<number, number> | null = null;
  if (exact) { palette = [...seen.keys()].map((k) => [k >> 16 & 255, k >> 8 & 255, k & 255]); map = seen; }
  else {
    const all = new Uint8Array(sample.reduce((a, s) => a + s.length, 0)); let off = 0; for (const s of sample) { all.set(s, off); off += s.length; }
    palette = quantize(all, limit, { format: 'rgb565' });
  }
  const tIdx = useTrans ? palette.length : -1;
  const full = useTrans ? [...palette, [0, 0, 0]] : palette;
  while (full.length < 2) full.push([0, 0, 0]);

  // pass 2: indices, difference against the previous frame, LZW
  const delaysCs = exactDelays(frames, fps);
  const gif = GIFEncoder(); let prev: Uint8Array | null = null;
  for (let n = 0; n < frames; n++) {
    const f = o.frame(n); let idx: Uint8Array;
    if (map) { idx = new Uint8Array(w * h); for (let i = 0, p = 0; i < f.length; i += 4, p++) idx[p] = map.get(f[i] << 16 | f[i + 1] << 8 | f[i + 2])!; }
    else idx = applyPalette(f as Uint8Array, palette, 'rgb565');
    const cur = idx; let out = idx;
    if (useTrans && prev) { out = new Uint8Array(idx); for (let p = 0; p < out.length; p++) if (out[p] === prev[p]) out[p] = tIdx; }
    gif.writeFrame(out, w, h, { palette: n === 0 ? full : undefined, delay: delaysCs[n] * 10, repeat: 0, transparent: useTrans && n > 0, transparentIndex: tIdx < 0 ? 0 : tIdx, dispose: useTrans ? 1 : -1 });
    prev = cur;
    if (o.onProgress && (n % 50 === 49 || n === frames - 1)) o.onProgress(n + 1, frames);
  }
  gif.finish();
  return { bytes: gif.bytes(), delaysCs, paletteSize: full.length, exact };
}
