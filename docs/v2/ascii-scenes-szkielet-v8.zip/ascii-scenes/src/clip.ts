// Wybor dlugosci klipu (krok 4.2). Own code (proj). Zasady: 04-eksport.md, sekcja 4.
import { DURATIONS } from './durations.ts';

export const DEFAULT_NO_LOOP_SECONDS = 10;

export type ClipRequest = {
  seconds?: number;                    // jawna dlugosc; ma pierwszenstwo przed petla
  repeat?: number;                     // n-krotne powtorzenie petli (wymaga petli)
  loop?: 'recommended' | 'exact';      // ktora petle uzyc (domyslnie rekomendowana)
  fps?: number;                        // fps wideo (domyslnie fps sceny)
};
export type Clip = {
  sceneFps: number; videoFps: number; frames: number; seconds: number;
  loopSeconds: number | null;          // okres petli uzyty do wyboru (null = brak)
  looped: boolean;                     // czy klip jest calkowita wielokrotnoscia petli (szew niewidoczny)
  warnings: string[];
};

export function resolveClip(id: string, req: ClipRequest = {}): Clip {
  const d = DURATIONS[id];
  if (!d) throw new Error(`no duration data for scene "${id}"`);
  if (!d.fps) throw new Error(`scene "${id}" is a still (fps 0): video export makes no sense, use PNG`);
  const sceneFps = d.fps, videoFps = req.fps ?? sceneFps;
  if (!(videoFps > 0)) throw new Error('fps must be > 0');
  const warnings: string[] = [];

  // period of the loop in scene frames and seconds
  let loopFrames: number | null = d.loopFrames, loopSeconds: number | null = d.loopSeconds;
  if (req.loop === 'exact') {
    if (d.exactSeconds === null) warnings.push(`scene "${id}" has no exact loop; using the recommended one`);
    else { loopSeconds = d.exactSeconds; loopFrames = Math.round(d.exactSeconds * sceneFps); }
  }
  if (req.seconds !== undefined && req.repeat !== undefined) throw new Error('give either seconds or repeat, not both');
  if (req.seconds !== undefined && !(req.seconds > 0)) throw new Error('seconds must be > 0');
  if (req.repeat !== undefined && !(Number.isInteger(req.repeat) && req.repeat >= 1)) throw new Error('repeat must be an integer >= 1');

  let seconds: number, frames: number, looped = false;
  const sameFps = videoFps === sceneFps;
  if (req.seconds !== undefined) {
    seconds = req.seconds; frames = Math.round(seconds * videoFps);
    if (loopSeconds === null) warnings.push(`scene "${id}" has no loop: the seam will be visible when the video repeats`);
    else {
      const m = seconds / loopSeconds;
      if (Math.abs(m - Math.round(m)) * loopSeconds * videoFps > 0.5) warnings.push(`${seconds} s is not a multiple of the loop period (${loopSeconds} s): the seam will be visible when the video repeats`);
      else looped = Math.round(m) >= 1;
    }
  } else if (req.repeat !== undefined) {
    if (loopSeconds === null || loopFrames === null) throw new Error(`scene "${id}" has no loop, repeat is not possible`);
    seconds = req.repeat * loopSeconds;
    frames = sameFps ? req.repeat * loopFrames : Math.round(seconds * videoFps); looped = true;
  } else if (loopSeconds !== null && loopFrames !== null) {
    seconds = loopSeconds; frames = sameFps ? loopFrames : Math.round(seconds * videoFps); looped = true;
  } else {
    seconds = DEFAULT_NO_LOOP_SECONDS; frames = Math.round(seconds * videoFps);
    warnings.push(`scene "${id}" has no loop: default clip of ${DEFAULT_NO_LOOP_SECONDS} s, the seam will be visible when the video repeats`);
  }
  if (looped && !sameFps && loopSeconds !== null) {
    const exact = (seconds * videoFps);
    if (Math.abs(exact - Math.round(exact)) > 0.01) warnings.push(`loop of ${seconds} s is ${exact.toFixed(2)} frames at ${videoFps} fps: rounded to ${Math.round(exact)}, the loop length drifts by ${(Math.round(exact) - exact).toFixed(2)} frame(s)`);
  }
  if (frames < 1) throw new Error('clip would have no frames');
  return { sceneFps, videoFps, frames, seconds: frames / videoFps, loopSeconds, looped, warnings };
}
