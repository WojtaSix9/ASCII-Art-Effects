// Offline renderer for text-mode ASCII scenes. No requestAnimationFrame, no DOM.
// Works with any canvas implementation that has the 2D API (browser OffscreenCanvas / @napi-rs/canvas).
// Own code (proj). The glyph-atlas idea follows ascii.rest src/mount.ts (MIT), but no code is copied here.

import { drawGeometric } from './glyphs.ts';

export type SceneMeta = { cols: number; rows: number; cell?: number; fps: number };

// Matches ScenePlayer (src/player.ts) [kod]: at(k, env?) returns the text of scene-frame k (t = k / fps).
// ScenePlayer does not expose meta, so the caller passes piece.meta separately.
export type PlayerLike = { at: (k: number, env?: { paper?: boolean }) => string };

export type RenderOptions = {
  width: number;            // output size in px
  height: number;
  ink?: string;             // default '#e8e8e8'
  background?: string | null; // null = transparent
  font?: string;            // family, default 'DejaVu Sans Mono, monospace'
  paper?: boolean;          // passed to the scene as env.paper (dark text on light ground). Default false.
};

export type CanvasFactory = (w: number, h: number) => any;

export type Layout = { cw: number; ch: number; x0: number; y0: number; fontPx: number };

export function computeLayout(meta: SceneMeta, width: number, height: number, advanceRatio: number): Layout {
  const cellH = meta.cell ?? 2; // cell height in cell widths
  const cw = Math.max(1, Math.floor(Math.min(width / meta.cols, height / (meta.rows * cellH))));
  const ch = Math.max(1, Math.round(cw * cellH));
  const x0 = Math.floor((width - cw * meta.cols) / 2);
  const y0 = Math.floor((height - ch * meta.rows) / 2);
  const fontPx = Math.max(1, Math.round(cw / advanceRatio));
  return { cw, ch, x0, y0, fontPx };
}

export type Rasterizer = {
  renderFrame: (player: PlayerLike, meta: SceneMeta, k: number, opts: RenderOptions) => any;
  drawText: (text: string, meta: SceneMeta, opts: RenderOptions) => any;
  drawTextInto: (canvas: any, text: string, meta: SceneMeta, opts: RenderOptions) => any;
  renderFrameInto: (canvas: any, player: PlayerLike, meta: SceneMeta, k: number, opts: RenderOptions) => any;
  // Canvas-free path (for video): composes the frame into a reusable RGBA buffer (width*height*4 bytes, straight alpha).
  // Colours must be #rgb or #rrggbb. Reading pixels back from a canvas leaks ~8 MB per 1080p frame (test), this does not.
  drawTextToBuffer: (out: Uint8Array, text: string, meta: SceneMeta, opts: RenderOptions) => Uint8Array;
  renderFrameToBuffer: (out: Uint8Array, player: PlayerLike, meta: SceneMeta, k: number, opts: RenderOptions) => Uint8Array;
  atlasSize: () => number;
};

export function createRasterizer(makeCanvas: CanvasFactory): Rasterizer {
  const atlases = new Map<string, { canvas: any; index: Map<string, number>; cw: number; ch: number; mask?: Uint8Array }>();
  const ratioCache = new Map<string, number>();

  function advanceRatio(font: string): number {
    let r = ratioCache.get(font);
    if (r === undefined) {
      const c = makeCanvas(10, 10);
      const g = c.getContext('2d');
      g.font = `100px ${font}`;
      r = g.measureText('M').width / 100;
      ratioCache.set(font, r);
    }
    return r;
  }

  // Atlas: one strip per (font, cell size, ink); glyphs added lazily, strip rebuilt on growth.
  function glyphSource(font: string, L: Layout, ink: string, chars: string[]) {
    const key = `${font}|${L.cw}x${L.ch}|${L.fontPx}|${ink}`;
    let a = atlases.get(key);
    const missing = a ? chars.filter((c) => !a!.index.has(c)) : chars;
    if (!a || missing.length) {
      const all = a ? Array.from(a.index.keys()).concat(missing) : missing;
      const canvas = makeCanvas(Math.max(1, all.length * L.cw), L.ch);
      const g = canvas.getContext('2d');
      g.font = `${L.fontPx}px ${font}`;
      g.textBaseline = 'middle';
      g.textAlign = 'center';
      g.fillStyle = ink;
      const index = new Map<string, number>();
      all.forEach((c, i) => {
        index.set(c, i);
        if (c === ' ') return;
        // Clip to the glyph's own cell: otherwise wide glyphs bleed into neighbours in the strip and the
        // pixels would depend on which glyphs happen to sit next to each other (found by test: synthwave, big-text).
        g.save();
        g.beginPath(); g.rect(i * L.cw, 0, L.cw, L.ch); g.clip();
        if (!drawGeometric(g, c, i * L.cw, 0, L.cw, L.ch)) g.fillText(c, i * L.cw + L.cw / 2, L.ch / 2 + L.fontPx * 0.04);
        g.restore();
      });
      a = { canvas, index, cw: L.cw, ch: L.ch };
      atlases.set(key, a);
    }
    return a;
  }

  // Draws one frame into an EXISTING canvas (its size must be opts.width x opts.height). The canvas is fully
  // overwritten (filled with the background or cleared), so one canvas can be reused for any number of frames.
  function drawTextInto(canvas: any, text: string, meta: SceneMeta, opts: RenderOptions) {
    if (canvas.width !== opts.width || canvas.height !== opts.height) {
      throw new Error(`canvas is ${canvas.width}x${canvas.height}, options say ${opts.width}x${opts.height}`);
    }
    const font = opts.font ?? 'DejaVu Sans Mono, monospace';
    const ink = opts.ink ?? '#e8e8e8';
    const bg = opts.background === undefined ? '#000000' : opts.background;
    const L = computeLayout(meta, opts.width, opts.height, advanceRatio(font));
    const lines = text.split('\n');
    if (lines.length !== meta.rows || lines.some((l) => Array.from(l).length !== meta.cols)) {
      throw new Error(`frame shape ${lines.length} rows, expected ${meta.rows}x${meta.cols}`);
    }
    const g = canvas.getContext('2d');
    g.globalCompositeOperation = 'source-over';
    g.globalAlpha = 1;
    if (bg === null) g.clearRect(0, 0, opts.width, opts.height);
    else { g.fillStyle = bg; g.fillRect(0, 0, opts.width, opts.height); }
    g.imageSmoothingEnabled = false;
    const uniq = Array.from(new Set(Array.from(text.replace(/\n/g, '')))).filter((c) => c !== ' ').sort();
    const a = glyphSource(font, L, ink, uniq);
    lines.forEach((line, r) => {
      Array.from(line).forEach((c, col) => {
        if (c === ' ') return;
        const i = a.index.get(c)!;
        g.drawImage(a.canvas, i * L.cw, 0, L.cw, L.ch, L.x0 + col * L.cw, L.y0 + r * L.ch, L.cw, L.ch);
      });
    });
    return canvas;
  }

  function drawText(text: string, meta: SceneMeta, opts: RenderOptions) {
    return drawTextInto(makeCanvas(opts.width, opts.height), text, meta, opts);
  }

  function parseHex(c: string): [number, number, number] {
    const m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(c);
    if (!m) throw new Error(`buffer renderer supports only #rgb / #rrggbb colours, got "${c}"`);
    const h = m[1].length === 3 ? m[1].split('').map((x) => x + x).join('') : m[1];
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }

  // Alpha masks of all glyphs of an atlas, glyph-major (glyph i occupies [i*cw*ch, (i+1)*cw*ch), row-major). Built once per atlas.
  function maskOf(a: { canvas: any; cw: number; ch: number; mask?: Uint8Array; index: Map<string, number> }): Uint8Array {
    if (a.mask) return a.mask;
    const W = a.canvas.width, H = a.canvas.height;
    const d = a.canvas.getContext('2d').getImageData(0, 0, W, H).data;
    const m = new Uint8Array(a.index.size * a.cw * a.ch);
    for (let i = 0; i < a.index.size; i++) {
      for (let y = 0; y < a.ch; y++) for (let x = 0; x < a.cw; x++) m[i * a.cw * a.ch + y * a.cw + x] = d[(y * W + i * a.cw + x) * 4 + 3];
    }
    a.mask = m;
    return m;
  }

  function drawTextToBuffer(out: Uint8Array, text: string, meta: SceneMeta, opts: RenderOptions) {
    const { width, height } = opts;
    if (out.length !== width * height * 4) throw new Error(`buffer has ${out.length} bytes, expected ${width * height * 4} (RGBA)`);
    const font = opts.font ?? 'DejaVu Sans Mono, monospace';
    const [ir, ig, ib] = parseHex(opts.ink ?? '#e8e8e8');
    const bgOpt = opts.background === undefined ? '#000000' : opts.background;
    const L = computeLayout(meta, width, height, advanceRatio(font));
    const lines = text.split('\n');
    if (lines.length !== meta.rows || lines.some((l) => Array.from(l).length !== meta.cols)) {
      throw new Error(`frame shape ${lines.length} rows, expected ${meta.rows}x${meta.cols}`);
    }
    // background
    let br = 0, bg = 0, bb = 0;
    if (bgOpt === null) out.fill(0);
    else {
      [br, bg, bb] = parseHex(bgOpt);
      if (out.byteOffset % 4 === 0) new Uint32Array(out.buffer, out.byteOffset, out.length / 4).fill(((255 << 24) | (bb << 16) | (bg << 8) | br) >>> 0);
      else for (let i = 0; i < out.length; i += 4) { out[i] = br; out[i + 1] = bg; out[i + 2] = bb; out[i + 3] = 255; }
    }
    const uniq = Array.from(new Set(Array.from(text.replace(/\n/g, '')))).filter((c) => c !== ' ').sort();
    const a = glyphSource(font, L, opts.ink ?? '#e8e8e8', uniq);
    const mask = maskOf(a);
    const cwh = L.cw * L.ch;
    lines.forEach((line, r) => {
      Array.from(line).forEach((c, col) => {
        if (c === ' ') return;
        const mo = a.index.get(c)! * cwh;
        for (let y = 0; y < L.ch; y++) {
          let o = ((L.y0 + r * L.ch + y) * width + L.x0 + col * L.cw) * 4;
          let mi = mo + y * L.cw;
          for (let x = 0; x < L.cw; x++, o += 4, mi++) {
            const al = mask[mi];
            if (al === 0) continue;
            if (bgOpt === null) { out[o] = ir; out[o + 1] = ig; out[o + 2] = ib; out[o + 3] = al; }
            else if (al === 255) { out[o] = ir; out[o + 1] = ig; out[o + 2] = ib; }
            else {
              const na = 255 - al;
              out[o] = ((br * na + ir * al + 127) / 255) | 0;
              out[o + 1] = ((bg * na + ig * al + 127) / 255) | 0;
              out[o + 2] = ((bb * na + ib * al + 127) / 255) | 0;
            }
          }
        }
      });
    });
    return out;
  }

  return {
    renderFrame: (player, meta, k, opts) => drawText(player.at(k, { paper: !!opts.paper }), meta, opts),
    drawText,
    drawTextInto,
    drawTextToBuffer,
    renderFrameToBuffer: (out: Uint8Array, player: PlayerLike, meta: SceneMeta, k: number, opts: RenderOptions) =>
      drawTextToBuffer(out, player.at(k, { paper: !!opts.paper }), meta, opts),
    renderFrameInto: (canvas: any, player: PlayerLike, meta: SceneMeta, k: number, opts: RenderOptions) =>
      drawTextInto(canvas, player.at(k, { paper: !!opts.paper }), meta, opts),
    atlasSize: () => atlases.size,
  };
}
