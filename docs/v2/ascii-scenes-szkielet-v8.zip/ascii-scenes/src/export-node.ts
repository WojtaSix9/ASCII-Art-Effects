// Export of single frames (PNG, text) in Node. Own code (proj). The core renderer (render.ts) stays environment-agnostic;
// everything that touches @napi-rs/canvas, the file system or the scene registry lives here.
import { createCanvas, GlobalFonts } from '@napi-rs/canvas';
import { existsSync } from 'node:fs';
import { pieces } from './registry.ts';
import { ScenePlayer } from './player.ts';
import { createRasterizer } from './render.ts';
import type { RenderOptions, SceneMeta } from './render.ts';

export type ExportSize = { width: number; height: number } | { cellPx: number };
export type FrameOptions = {
  ink?: string;                 // default '#7CFFB2'
  background?: string | null;   // default '#0a0a0a'; null = transparent (PNG only)
  size?: ExportSize;            // default 1920x1080 (grid centred, letterbox); { cellPx: N } = size follows the grid
  font?: string;                // default 'DejaVu Sans Mono, monospace'
  paper?: boolean;              // passed to the scene as env.paper
};

export const DEFAULTS = { ink: '#7CFFB2', background: '#0a0a0a', width: 1920, height: 1080 };
const FONT_PATHS = ['/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'];

let fontChecked = false;
export function ensureFont(): void {
  if (fontChecked) return;
  fontChecked = true;
  for (const p of FONT_PATHS) if (existsSync(p)) { GlobalFonts.registerFromPath(p, 'DejaVu Sans Mono'); return; }
  // TODO(proj?): ship a font file with the repo so output does not depend on system fonts.
  console.warn('export: DejaVu Sans Mono not found, falling back to the system monospace font (pixels will differ).');
}

export const rasterizer = createRasterizer((w: number, h: number) => createCanvas(w, h));

export function sceneIds(): string[] { return Object.keys(pieces); }

export function getScene(id: string) {
  const piece = pieces[id];
  if (!piece) throw new Error(`unknown scene "${id}". Available: ${sceneIds().join(', ')}`);
  return { piece, meta: piece.meta as SceneMeta };
}

export function resolveSize(meta: SceneMeta, size?: ExportSize): { width: number; height: number } {
  if (!size) return { width: DEFAULTS.width, height: DEFAULTS.height };
  if ('cellPx' in size) {
    const cw = Math.round(size.cellPx);
    if (!(cw >= 1)) throw new Error('cellPx must be >= 1');
    return { width: meta.cols * cw, height: meta.rows * Math.round(cw * (meta.cell ?? 2)) };
  }
  if (!(size.width >= 1 && size.height >= 1)) throw new Error('size must be positive');
  return { width: Math.round(size.width), height: Math.round(size.height) };
}

export function renderOptions(meta: SceneMeta, o: FrameOptions = {}): RenderOptions {
  const { width, height } = resolveSize(meta, o.size);
  return {
    width, height,
    ink: o.ink ?? DEFAULTS.ink,
    background: o.background === undefined ? DEFAULTS.background : o.background,
    font: o.font, paper: o.paper,
  };
}

function checkFrameIndex(k: number) {
  if (!Number.isInteger(k) || k < 0) throw new Error('frame index k must be an integer >= 0');
}

/** Text of frame k exactly as the scene returns it (rows lines of cols characters), plus a final newline. */
export function exportText(id: string, k = 0, o: { trimEnd?: boolean } = {}): string {
  checkFrameIndex(k);
  const { piece, meta } = getScene(id);
  const text = new ScenePlayer(piece, id).at(k);
  const lines = text.split('\n');
  if (lines.length !== meta.rows) throw new Error(`frame has ${lines.length} rows, meta says ${meta.rows}`);
  return (o.trimEnd ? lines.map((l) => l.replace(/\s+$/, '')) : lines).join('\n') + '\n';
}

/** PNG (Buffer) of frame k. background: null gives a transparent PNG. */
export function exportPng(id: string, k = 0, o: FrameOptions = {}): Buffer {
  checkFrameIndex(k);
  ensureFont();
  const { piece, meta } = getScene(id);
  const opts = renderOptions(meta, o);
  const canvas = createCanvas(opts.width, opts.height);
  rasterizer.renderFrameInto(canvas, new ScenePlayer(piece, id), meta, k, opts);
  return canvas.toBuffer('image/png');
}
