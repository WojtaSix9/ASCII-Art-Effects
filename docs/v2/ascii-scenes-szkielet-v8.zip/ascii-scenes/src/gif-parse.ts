// Minimal GIF89a inspector (proj): frame count, per-frame delays (centiseconds), loop count, size, palette sizes.
// Own code, no dependencies; used by the GIF tests. Does not decode pixels.
export type GifInfo = {
  width: number; height: number; frames: number;
  delaysCs: number[];            // per frame, from the Graphic Control Extension (0 if missing)
  loop: number | null;           // NETSCAPE2.0 loop count: 0 = forever, null = extension absent (plays once)
  globalColors: number; localPaletteFrames: number;
  transparentFrames: number;     // frames whose GCE has the transparency flag
  delayOffsets: number[];        // byte offset of each frame's 2-byte delay field (for setGifDelays)
};

export function parseGif(b: Buffer): GifInfo {
  const sig = b.toString('latin1', 0, 6);
  if (sig !== 'GIF89a' && sig !== 'GIF87a') throw new Error('not a GIF');
  const width = b.readUInt16LE(6), height = b.readUInt16LE(8);
  const packed = b[10];
  let p = 13;
  const globalColors = packed & 0x80 ? 2 ** ((packed & 7) + 1) : 0;
  if (globalColors) p += 3 * globalColors;
  const info: GifInfo = { width, height, frames: 0, delaysCs: [], loop: null, globalColors, localPaletteFrames: 0, transparentFrames: 0, delayOffsets: [] };
  let pendingDelay = 0, pendingTransparent = false, pendingOffset = -1;
  const skipSub = () => { while (b[p] !== 0) p += b[p] + 1; p++; };
  while (p < b.length) {
    const t = b[p++];
    if (t === 0x3b) break;
    if (t === 0x21) {
      const label = b[p++];
      if (label === 0xf9) { pendingTransparent = !!(b[p + 1] & 1); pendingDelay = b.readUInt16LE(p + 2); pendingOffset = p + 2; p += 1 + b[p]; p++; }
      else if (label === 0xff) {
        const id = b.toString('latin1', p + 1, p + 1 + b[p]); p += 1 + b[p];
        if (id === 'NETSCAPE2.0' && b[p] >= 3 && b[p + 1] === 1) info.loop = b.readUInt16LE(p + 2);
        skipSub();
      } else { p += 0; skipSub(); }
    } else if (t === 0x2c) {
      const lp = b[p + 8];
      p += 9;
      if (lp & 0x80) { info.localPaletteFrames++; p += 3 * 2 ** ((lp & 7) + 1); }
      p++; skipSub();                         // LZW min code size + data sub-blocks
      info.frames++; info.delaysCs.push(pendingDelay); info.delayOffsets.push(pendingOffset); if (pendingTransparent) info.transparentFrames++;
      pendingDelay = 0; pendingTransparent = false; pendingOffset = -1;
    } else throw new Error(`unexpected GIF block 0x${t.toString(16)} at ${p - 1}`);
  }
  return info;
}

/** Exact per-frame delays in centiseconds for a constant fps: delay_i = round((i+1)*100/fps) - round(i*100/fps).
 *  The sum is round(n*100/fps) for any n, so the loop length does not drift (a GIF delay is an integer number of 1/100 s). */
export function exactDelays(frames: number, fps: number): number[] {
  const out: number[] = [];
  for (let i = 0; i < frames; i++) out.push(Math.round((i + 1) * 100 / fps) - Math.round(i * 100 / fps));
  return out;
}

/** Overwrites the frame delays in place (returns the same buffer). Needs one Graphic Control Extension per frame. */
export function setGifDelays(b: Buffer, delaysCs: number[]): Buffer {
  const info = parseGif(b);
  if (info.frames !== delaysCs.length) throw new Error(`GIF has ${info.frames} frames, ${delaysCs.length} delays given`);
  info.delayOffsets.forEach((off, i) => { if (off < 0) throw new Error(`frame ${i} has no Graphic Control Extension`); b.writeUInt16LE(delaysCs[i], off); });
  return b;
}
