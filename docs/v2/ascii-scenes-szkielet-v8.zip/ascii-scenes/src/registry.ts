// Rejestr scen startowych (30). Kolejnosc: efekty, generatywne, bryly, natura, fizyka, typografia.
import type { Piece } from "./types.ts";
import * as doomFire from "./pieces/doom-fire.ts";
import * as matrixRain from "./pieces/matrix-rain.ts";
import * as plasma from "./pieces/plasma.ts";
import * as tunnel from "./pieces/tunnel.ts";
import * as tvStatic from "./pieces/tv-static.ts";
import * as synthwave from "./pieces/synthwave.ts";
import * as fireworks from "./pieces/fireworks.ts";
import * as mandelbrot from "./pieces/mandelbrot.ts";
import * as voronoi from "./pieces/voronoi.ts";
import * as reactionDiffusion from "./pieces/reaction-diffusion.ts";
import * as flowField from "./pieces/flow-field.ts";
import * as donut from "./pieces/donut.ts";
import * as cube from "./pieces/cube.ts";
import * as tesseract from "./pieces/tesseract.ts";
import * as torusKnot from "./pieces/torus-knot.ts";
import * as dnaHelix from "./pieces/dna-helix.ts";
import * as rain from "./pieces/rain.ts";
import * as snowfall from "./pieces/snowfall.ts";
import * as aurora from "./pieces/aurora.ts";
import * as fireflies from "./pieces/fireflies.ts";
import * as campfire from "./pieces/campfire.ts";
import * as waveInterference from "./pieces/wave-interference.ts";
import * as pondRipples from "./pieces/pond-ripples.ts";
import * as fallingSand from "./pieces/falling-sand.ts";
import * as smoke from "./pieces/smoke.ts";
import * as bigText from "./pieces/big-text.ts";
import * as typewriter from "./pieces/typewriter.ts";
import * as glitch from "./pieces/glitch.ts";
import * as waveText from "./pieces/wave-text.ts";
import * as scramble from "./pieces/scramble.ts";

export const pieces: Record<string, Piece<any>> = {
  "doom-fire": doomFire,
  "matrix-rain": matrixRain,
  "plasma": plasma,
  "tunnel": tunnel,
  "tv-static": tvStatic,
  "synthwave": synthwave,
  "fireworks": fireworks,
  "mandelbrot": mandelbrot,
  "voronoi": voronoi,
  "reaction-diffusion": reactionDiffusion,
  "flow-field": flowField,
  "donut": donut,
  "cube": cube,
  "tesseract": tesseract,
  "torus-knot": torusKnot,
  "dna-helix": dnaHelix,
  "rain": rain,
  "snowfall": snowfall,
  "aurora": aurora,
  "fireflies": fireflies,
  "campfire": campfire,
  "wave-interference": waveInterference,
  "pond-ripples": pondRipples,
  "falling-sand": fallingSand,
  "smoke": smoke,
  "big-text": bigText,
  "typewriter": typewriter,
  "glitch": glitch,
  "wave-text": waveText,
  "scramble": scramble,
};
